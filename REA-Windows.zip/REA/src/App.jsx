import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity, ArrowDownLeft, ArrowRight, ArrowUpRight, Bell, CarFront, Check, CheckCheck,
  ChevronRight, CircleDollarSign, Clock3, CreditCard, Gauge, LayoutDashboard,
  LoaderCircle, LogOut, MapPin, Menu, Navigation, Route, Search, Settings2,
  ShieldCheck, SlidersHorizontal, Smartphone, Star, Users, Wifi, X, AlertCircle,
  CalendarDays, CheckCircle2, Ban, RefreshCw, Eye, Mail, Phone, LockKeyhole,
} from 'lucide-react';

const currency = value => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format((value || 0) / 100);
const number = value => new Intl.NumberFormat('pt-BR').format(value || 0);
const dateTime = value => value ? new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short', timeZone: 'America/Sao_Paulo' }).format(new Date(value)) : '—';
const shortTime = value => new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit', timeZone: 'America/Sao_Paulo' }).format(new Date(value));
const initials = name => (name || '?').split(' ').filter(Boolean).slice(0, 2).map(word => word[0]).join('').toUpperCase();
const statusInfo = {
  requested: ['Buscando motorista', 'waiting'], accepted: ['A caminho', 'blue'], arrived: ['No embarque', 'blue'],
  in_progress: ['Em andamento', 'green'], completed: ['Concluída', 'neutral'], cancelled: ['Cancelada', 'red'],
};
const activeStatuses = ['requested', 'accepted', 'arrived', 'in_progress'];
const navItems = [
  { id: 'overview', label: 'Visão geral', Icon: LayoutDashboard },
  { id: 'rides', label: 'Corridas', Icon: Route },
  { id: 'drivers', label: 'Motoristas', Icon: CarFront },
  { id: 'riders', label: 'Passageiros', Icon: Users },
  { id: 'settings', label: 'Tarifas e operação', Icon: SlidersHorizontal },
];

async function request(path, options = {}) {
  const { body, ...rest } = options;
  const response = await fetch(`/api${path}`, {
    credentials: 'same-origin', ...rest,
    headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(rest.headers || {}) },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(typeof result.error === 'string' ? result.error : 'Não foi possível concluir a solicitação.');
    error.status = response.status;
    throw error;
  }
  return result;
}

function Brand({ light = false }) {
  return <a href="#" className={`brand ${light ? 'brand-light' : ''}`} aria-label="REA Mobilidade, início" onClick={event => event.preventDefault()}>
    <span className="brand-symbol" aria-hidden="true"><Navigation size={24} strokeWidth={2.6} /></span>
    <span className="brand-word">rea<span className="brand-dot">.</span><small>mobilidade</small></span>
  </a>;
}
function Badge({ status }) {
  const [label, tone] = statusInfo[status] || [status, 'neutral'];
  return <span className={`badge badge-${tone}`}><i />{label}</span>;
}
function Avatar({ name, color = 'green', small = false }) {
  return <span className={`avatar avatar-${color} ${small ? 'avatar-small' : ''}`} aria-hidden="true">{initials(name)}</span>;
}
function Empty({ Icon = Route, title = 'Nada por aqui ainda', children }) {
  return <div className="empty-state"><span><Icon size={28} /></span><h3>{title}</h3><p>{children}</p></div>;
}
function ActionButton({ busy, disabled, children, className = 'button primary', ...props }) {
  return <button {...props} className={className} disabled={busy || disabled} aria-busy={busy || undefined}>{busy && <LoaderCircle className="spin" size={17} />}{children}</button>;
}

function Login({ demoMode, onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(event) {
    event.preventDefault(); setBusy(true); setError('');
    try { await onLogin(email, password); } catch (cause) { setError(cause.message); } finally { setBusy(false); }
  }
  return <div className="login-layout">
    <section className="login-story">
      <Brand light />
      <div className="login-story-copy"><span className="eyebrow light"><span className="pulse-dot" /> CENTRAL DE MOBILIDADE</span>
        <h1>Conectando pessoas.<br /><em>Movendo cidades.</em></h1>
        <p>Uma visão completa da sua operação.<br />Cada motorista, cada passageiro, cada corrida.</p>
      </div>
      <div className="login-road" aria-hidden="true"><div className="road-ring ring-one" /><div className="road-ring ring-two" /><div className="road-ring ring-three" /><span className="road-point point-one"><MapPin /></span><span className="road-point point-two"><CarFront /></span><span className="road-point point-three"><Navigation /></span><span className="road-label">O próximo destino começa aqui.</span></div>
      <div className="login-footer"><ShieldCheck size={16} /> Gestão conectada, do embarque ao destino.</div>
    </section>
    <section className="login-panel"><div className="login-form-wrap">
      <div className="login-mobile-brand"><Brand /></div>
      <span className="login-icon"><LockKeyhole size={24} /></span>
      <span className="eyebrow">PORTAL SUPERADMIN</span><h2>Bom ter você aqui.</h2><p className="muted login-intro">Entre para acompanhar e gerenciar sua operação.</p>
      <form onSubmit={submit}>
        <label htmlFor="login-email">E-mail</label><div className="input-icon"><Mail size={18} /><input id="login-email" type="email" autoComplete="username" placeholder="voce@suaempresa.com" required value={email} onChange={event => setEmail(event.target.value)} /></div>
        <label htmlFor="login-password">Senha</label><div className="input-icon"><LockKeyhole size={18} /><input id="login-password" type="password" autoComplete="current-password" placeholder="Sua senha de acesso" required value={password} onChange={event => setPassword(event.target.value)} /></div>
        {error && <div className="error-message" role="alert"><AlertCircle size={18} />{error}</div>}
        <ActionButton type="submit" busy={busy} className="button primary login-submit">Acessar painel <ArrowRight size={18} /></ActionButton>
      </form>
      {demoMode && <div className="demo-login"><span className="badge badge-waiting">Demonstração local</span><p>Explore o painel com contas e corridas de teste.</p><button type="button" className="text-button" onClick={() => { setEmail('admin@rea.local'); setPassword('ReaDemo!2026'); setError(''); }}>Preencher acesso de demonstração <ArrowRight size={15} /></button></div>}
      <div className="login-mobile-note"><Smartphone size={20} /><p>Passageiro ou motorista?<br /><strong>Use seu aplicativo REA.</strong></p></div>
    </div><p className="login-copyright">REA Mobilidade · Central de operação</p></section>
  </div>;
}

function RevenueChart({ rides }) {
  const formatter = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo', year: 'numeric', month: '2-digit', day: '2-digit' });
  const days = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(); date.setDate(date.getDate() - (6 - index));
    const key = formatter.format(date);
    const total = rides.filter(ride => ride.status === 'completed' && formatter.format(new Date(ride.updatedAt)) === key).reduce((sum, ride) => sum + ride.totalCents, 0);
    return { key, total, label: new Intl.DateTimeFormat('pt-BR', { weekday: 'short', timeZone: 'America/Sao_Paulo' }).format(date).replace('.', '') };
  });
  const total = days.reduce((sum, day) => sum + day.total, 0);
  const max = Math.max(...days.map(day => day.total), 100);
  return <section className="card revenue-card">
    <div className="card-heading"><div><h2>Receita de corridas</h2><p>Valores brutos das corridas concluídas</p></div><span className="period-label"><CalendarDays size={14} /> Últimos 7 dias</span></div>
    <div className="revenue-total">{currency(total)}<span>no período</span></div>
    <div className="bar-chart" role="img" aria-label={`Receita dos últimos 7 dias: ${currency(total)}. ${days.map(day => `${day.label}: ${currency(day.total)}`).join('. ')}`}>
      <div className="chart-grid"><span>{currency(max)}</span><span>{currency(max / 2)}</span><span>R$ 0</span></div>
      <div className="chart-bars">{days.map((day, index) => <div className="bar-column" key={day.key}><div className="bar-space"><span className={`chart-bar ${index === 6 ? 'today' : ''}`} style={{ height: `${Math.max(day.total ? 4 : 0, day.total / max * 100)}%` }} title={currency(day.total)} /></div><span>{day.label}</span></div>)}</div>
    </div>
  </section>;
}

function LiveMap({ rides, onSelect }) {
  const active = rides.filter(ride => activeStatuses.includes(ride.status));
  const points = active.flatMap(ride => [ride.origin, ride.destination]).filter(Boolean);
  const minLat = Math.min(-23.61, ...points.map(point => point.lat));
  const maxLat = Math.max(-23.51, ...points.map(point => point.lat));
  const minLng = Math.min(-46.72, ...points.map(point => point.lng));
  const maxLng = Math.max(-46.6, ...points.map(point => point.lng));
  const position = place => [25 + (place.lng - minLng) / (maxLng - minLng) * 350, 190 - (place.lat - minLat) / (maxLat - minLat) * 160];
  return <section className="card map-card"><div className="card-heading"><div><h2>Operação agora</h2><p>{active.length ? `${active.length} corrida${active.length > 1 ? 's' : ''} em atividade` : 'Aguardando novas corridas'}</p></div><span className="live-tag"><i /> Corridas ativas</span></div>
    <div className="operation-map"><svg viewBox="0 0 400 220" aria-label="Trajetos esquemáticos das corridas ativas" role="img">
      <defs><pattern id="city-grid" x="0" y="0" width="48" height="48" patternUnits="userSpaceOnUse" patternTransform="rotate(-18)"><rect width="48" height="48" fill="#edf1e8" /><rect x="5" y="5" width="34" height="34" rx="5" fill="#e1e8da" /><path d="M43 0V48M0 43H48" stroke="#fff" strokeWidth="7" /></pattern></defs>
      <rect width="400" height="220" fill="url(#city-grid)" /><path d="M-20 170C95 115 130 205 235 130S330 80 430 115" fill="none" stroke="#c5dfdd" strokeWidth="19" /><path d="M-20 175C95 120 130 210 235 135S330 85 430 120" fill="none" stroke="#afcfcd" strokeWidth="2" />
      {active.slice(0, 12).map(ride => {
        const [x1, y1] = position(ride.origin); const [x2, y2] = position(ride.destination);
        return <g key={ride.id}><path d={`M${x1} ${y1} Q${x1} ${y2} ${x2} ${y2}`} stroke="#26726a" strokeWidth="3" strokeDasharray="5 4" fill="none" /><circle cx={x1} cy={y1} r="7" fill="#173f3a" stroke="white" strokeWidth="3" /><circle cx={x2} cy={y2} r="7" fill="#b6d777" stroke="white" strokeWidth="3" /></g>;
      })}
    </svg>{!active.length && <div className="map-empty"><span><CarFront size={22} /></span><strong>Prontos para o próximo destino</strong><small>As novas corridas aparecem aqui.</small></div>}
    <span className="map-city"><MapPin size={12} /> São Paulo</span></div>
    <div className="map-caption"><span>Trajetos esquemáticos · sem navegação</span>{active.length > 0 && <button className="text-button" onClick={() => onSelect(active[0])}>Detalhes <ArrowRight size={14} /></button>}</div>
  </section>;
}

function RideTable({ rides, onSelect, compact = false }) {
  if (!rides.length) return <Empty title="Nenhuma corrida encontrada">As solicitações dos passageiros aparecerão aqui.</Empty>;
  return <div className="table-scroll"><table className="data-table rides-table"><thead><tr><th>Passageiro / corrida</th><th>Trajeto</th>{!compact && <th>Motorista</th>}<th>Valor</th><th>Status</th><th><span className="sr-only">Detalhes</span></th></tr></thead>
    <tbody>{rides.map(ride => <tr key={ride.id}>
      <td><div className="person-cell"><Avatar name={ride.riderName} color="sand" small /><div><strong>{ride.riderName || 'Passageiro'}</strong><small>#{String(ride.id).slice(-6).toUpperCase()} · {dateTime(ride.createdAt)}</small></div></div></td>
      <td><div className="route-cell"><span><i />{ride.origin?.name || 'Origem'}</span><span><i />{ride.destination?.name || 'Destino'}</span></div></td>
      {!compact && <td><span className={ride.driverName ? '' : 'muted'}>{ride.driverName || 'Aguardando motorista'}</span></td>}
      <td className="money-cell">{currency(ride.totalCents)}<small>{ride.category === 'comfort' ? 'Conforto' : 'Econômico'}</small></td><td><Badge status={ride.status} /></td>
      <td><button className="icon-button" aria-label={`Ver corrida de ${ride.riderName}`} onClick={() => onSelect(ride)}><ArrowUpRight size={18} /></button></td>
    </tr>)}</tbody></table></div>;
}

function Overview({ dashboard, setPage, onSelect }) {
  const { stats = {}, rides = [], users = [] } = dashboard;
  const pending = users.filter(user => user.role === 'driver' && !user.approved).length;
  const completed = rides.filter(ride => ride.status === 'completed');
  const commission = completed.reduce((sum, ride) => sum + (ride.commissionCents || 0), 0);
  return <>
    <div className="page-intro"><div><span className="eyebrow">SUA CENTRAL DE CONTROLE</span><h1>Sua operação, em movimento<span>.</span></h1><p>Acompanhe o que acontece e cuide de cada conexão.</p></div><button className="button primary" onClick={() => setPage('rides')}>Acompanhar corridas <ArrowUpRight size={17} /></button></div>
    <div className="metrics-grid">
      <Metric label="Corridas em atividade" value={number(stats.activeRides)} note={`${number(stats.totalRides)} corridas registradas`} Icon={Route} accent="green" />
      <Metric label="Receita total" value={currency(stats.totalRevenueCents)} note={`${currency(commission)} em comissões`} Icon={CircleDollarSign} accent="lime" />
      <Metric label="Motoristas online" value={number(stats.onlineDrivers)} note={`${users.filter(user => user.role === 'driver').length} parceiros cadastrados`} Icon={CarFront} accent="blue" />
      <Metric label="Corridas concluídas" value={number(stats.completedRides)} note={stats.totalRides ? `${Math.round((stats.completedRides || 0) / stats.totalRides * 100)}% do total de corridas` : 'Seu histórico começa aqui'} Icon={CheckCheck} accent="sand" />
    </div>
    {pending > 0 && <button className="pending-banner" onClick={() => setPage('drivers')}><span className="pending-banner-icon"><ShieldCheck size={19} /></span><span><strong>{pending} motorista{pending > 1 ? 's' : ''} aguardando aprovação</strong><small>Confira os cadastros para liberar novos parceiros.</small></span><ArrowRight size={18} /></button>}
    <div className="analytics-grid"><RevenueChart rides={rides} /><LiveMap rides={rides} onSelect={onSelect} /></div>
    <section className="card"><div className="card-heading"><div><h2>Últimas corridas <span className="count-pill">{rides.length}</span></h2><p>Do primeiro chamado ao destino final</p></div><button className="text-button" onClick={() => setPage('rides')}>Ver todas <ArrowRight size={16} /></button></div><RideTable rides={rides.slice(0, 5)} onSelect={onSelect} compact /></section>
    <div className="overview-footer"><ShieldCheck size={15} /><span>Passageiros, motoristas e operação na mesma conexão.</span><span className="footer-location">São Paulo, Brasil</span></div>
  </>;
}
function Metric({ label, value, note, Icon, accent }) {
  return <div className="metric-card"><div className="metric-top"><span>{label}</span><span className={`metric-icon icon-${accent}`}><Icon size={19} /></span></div><strong className="metric-value">{value}</strong><span className="metric-note">{note}</span></div>;
}

function Rides({ rides, onSelect }) {
  const [query, setQuery] = useState(''); const [status, setStatus] = useState('all');
  const results = rides.filter(ride => (status === 'all' || (status === 'active' ? activeStatuses.includes(ride.status) : ride.status === status)) && [ride.riderName, ride.driverName, ride.id, ride.origin?.name, ride.destination?.name].join(' ').toLocaleLowerCase('pt-BR').includes(query.toLocaleLowerCase('pt-BR')));
  return <><PageIntro eyebrow="CADA CONEXÃO IMPORTA" title="Central de corridas" description="Acompanhe solicitações, trajetos e o histórico da operação." />
    <section className="card"><div className="table-toolbar"><div className="search-field"><Search size={17} /><input aria-label="Buscar corridas" placeholder="Buscar pessoa, local ou corrida" value={query} onChange={event => setQuery(event.target.value)} /></div><label className="select-filter"><SlidersHorizontal size={16} /><select aria-label="Filtrar status da corrida" value={status} onChange={event => setStatus(event.target.value)}><option value="all">Todos os status</option><option value="active">Em atividade</option>{Object.entries(statusInfo).map(([value, [label]]) => <option key={value} value={value}>{label}</option>)}</select></label></div>
      <div className="results-caption">{results.length} corrida{results.length === 1 ? '' : 's'} encontrada{results.length === 1 ? '' : 's'}</div><RideTable rides={results} onSelect={onSelect} /></section></>;
}
function PageIntro({ eyebrow, title, description, children }) {
  return <div className="page-intro"><div><span className="eyebrow">{eyebrow}</span><h1>{title}<span>.</span></h1><p>{description}</p></div>{children}</div>;
}

function People({ dashboard, kind, onUpdate, notify }) {
  const isDriver = kind === 'driver'; const [query, setQuery] = useState(''); const [filter, setFilter] = useState('all'); const [busyId, setBusyId] = useState(null);
  const people = dashboard.users.filter(user => user.role === kind);
  const results = people.filter(user => [user.name, user.email, user.vehicle?.plate].join(' ').toLocaleLowerCase('pt-BR').includes(query.toLocaleLowerCase('pt-BR')) && (filter === 'all' || (filter === 'pending' ? !user.approved : user.online)));
  async function changeApproval(user) {
    setBusyId(user.id);
    try { await request(`/admin/users/${encodeURIComponent(user.id)}`, { method: 'PATCH', body: { approved: !user.approved } }); await onUpdate(); notify(user.approved ? 'Aprovação do motorista revogada.' : 'Motorista aprovado. Ele já pode ficar online.'); } catch (error) { notify(error.message, 'error'); } finally { setBusyId(null); }
  }
  return <><PageIntro eyebrow={isDriver ? 'QUEM MOVE A CIDADE' : 'QUEM CONFIA NA SUA OPERAÇÃO'} title={isDriver ? 'Motoristas parceiros' : 'Passageiros'} description={isDriver ? 'Gerencie cadastros e acompanhe a disponibilidade dos parceiros.' : 'Consulte os passageiros e suas conexões com a REA.'} />
    <div className={`people-metrics ${isDriver ? '' : 'two-columns'}`}><Metric label={isDriver ? 'Parceiros cadastrados' : 'Passageiros cadastrados'} value={number(people.length)} note="Cadastros da operação" Icon={isDriver ? CarFront : Users} accent="green" />{isDriver && <Metric label="Disponíveis agora" value={number(people.filter(user => user.online).length)} note="Parceiros com status online" Icon={Activity} accent="lime" />}<Metric label={isDriver ? 'Aguardando aprovação' : 'Corridas concluídas'} value={number(isDriver ? people.filter(user => !user.approved).length : dashboard.stats.completedRides)} note={isDriver ? 'Cadastros para revisar' : 'Destinos alcançados'} Icon={isDriver ? ShieldCheck : CheckCheck} accent="sand" /></div>
    <section className="card"><div className="table-toolbar"><div className="search-field"><Search size={17} /><input aria-label={isDriver ? 'Buscar motorista' : 'Buscar passageiro'} placeholder={isDriver ? 'Buscar nome, e-mail ou placa' : 'Buscar nome ou e-mail'} value={query} onChange={event => setQuery(event.target.value)} /></div>{isDriver && <label className="select-filter"><SlidersHorizontal size={16} /><select aria-label="Filtrar motoristas" value={filter} onChange={event => setFilter(event.target.value)}><option value="all">Todos os parceiros</option><option value="pending">Aguardando aprovação</option><option value="online">Online agora</option></select></label>}</div>
    {!results.length ? <Empty Icon={isDriver ? CarFront : Users} title="Nenhum cadastro encontrado">Os novos cadastros feitos pelo aplicativo aparecem aqui.</Empty> : <div className="table-scroll"><table className="data-table"><thead><tr><th>{isDriver ? 'Motorista' : 'Passageiro'}</th><th>Contato</th>{isDriver && <th>Veículo</th>}<th>{isDriver ? 'Disponibilidade' : 'Corridas'}</th>{isDriver && <th>Aprovação</th>}</tr></thead><tbody>{results.map(user => <tr key={user.id}><td><div className="person-cell"><Avatar name={user.name} color={isDriver ? 'green' : 'sand'} /><div><strong>{user.name}</strong><small>#{String(user.id).slice(-6).toUpperCase()}</small></div></div></td><td><div className="contact-cell"><span>{user.email}</span><small>{user.phone || 'Telefone não informado'}</small></div></td>{isDriver && <td><div className="contact-cell"><strong>{user.vehicle?.model || 'Não informado'}</strong><small>{[user.vehicle?.plate, user.vehicle?.color].filter(Boolean).join(' · ')}</small></div></td>}<td>{isDriver ? <span className={`badge ${user.online ? 'badge-green' : 'badge-neutral'}`}><i />{user.online ? 'Online' : 'Offline'}</span> : <span className="ride-count">{dashboard.rides.filter(ride => ride.riderId === user.id).length} corridas</span>}</td>{isDriver && <td><div className="approval-cell"><span className={`approval-label ${user.approved ? 'approved' : ''}`}>{user.approved ? <CheckCircle2 size={14} /> : <Clock3 size={14} />}{user.approved ? 'Aprovado' : 'Pendente'}</span><ActionButton busy={busyId === user.id} className={`button button-small ${user.approved ? 'subtle' : 'primary'}`} onClick={() => changeApproval(user)}>{user.approved ? 'Revogar' : 'Aprovar'}</ActionButton></div></td>}</tr>)}</tbody></table></div>}</section>
    {isDriver && <p className="section-note"><ShieldCheck size={16} /> A aprovação libera o acesso às solicitações de corrida. A disponibilidade é controlada pelo motorista no aplicativo.</p>}
    </>;
}

function pricingDraft(settings) {
  return { baseFare: String(settings.baseFareCents / 100), perKm: String(settings.perKmCents / 100), minimumFare: String(settings.minimumFareCents / 100), commissionPercent: String(settings.commissionPercent), comfortMultiplier: String(settings.comfortMultiplier) };
}
function Pricing({ settings, onUpdate, notify }) {
  const [draft, setDraft] = useState(() => pricingDraft(settings));
  const [busy, setBusy] = useState(false);
  const [dirty, setDirty] = useState(false);
  const settingsKey = JSON.stringify(settings);
  const [editingVersion, setEditingVersion] = useState(settingsKey);
  const stale = dirty && editingVersion !== settingsKey;
  useEffect(() => {
    if (!dirty) { setDraft(pricingDraft(settings)); setEditingVersion(settingsKey); }
  }, [settingsKey, dirty]);
  function change(field, value) { setDirty(true); setDraft(previous => ({ ...previous, [field]: value })); }
  function reload() { setDirty(false); setDraft(pricingDraft(settings)); setEditingVersion(settingsKey); }
  const estimated = Math.max(Number(draft.minimumFare), Number(draft.baseFare) + Number(draft.perKm) * 5);
  async function save(event) {
    event.preventDefault();
    if (stale) return;
    setBusy(true);
    try {
      await request('/admin/settings', { method: 'PATCH', body: { baseFareCents: Math.round(Number(draft.baseFare) * 100), perKmCents: Math.round(Number(draft.perKm) * 100), minimumFareCents: Math.round(Number(draft.minimumFare) * 100), commissionPercent: Number(draft.commissionPercent), comfortMultiplier: Number(draft.comfortMultiplier) } });
      await onUpdate(); setDirty(false); notify('Tarifas salvas. Novas solicitações usarão esses valores.');
    } catch (error) { notify(error.message, 'error'); } finally { setBusy(false); }
  }
  return <><PageIntro eyebrow="OS DETALHES FAZEM A DIFERENÇA" title="Tarifas e operação" description="Defina preços claros para passageiros e motoristas parceiros." />
    <div className="pricing-layout"><form className="card pricing-form" onSubmit={save}>{stale && <div className="pricing-stale" role="alert"><AlertCircle size={18} /><span>As tarifas foram alteradas em outra sessão. Recarregue os valores antes de salvar.</span><button type="button" className="text-button" onClick={reload}>Recarregar valores</button></div>}<div className="card-heading"><div><h2>Composição da tarifa</h2><p>Os novos valores se aplicam às próximas corridas.</p></div><span className="card-title-icon"><Settings2 size={21} /></span></div><div className="pricing-fields">
      <PricingField label="Tarifa base" id="baseFare" value={draft.baseFare} suffix="R$" hint="Valor inicial de cada corrida." min="0" max="1000" step="0.01" onChange={value => change('baseFare', value)} disabled={busy} />
      <PricingField label="Valor por quilômetro" id="perKm" value={draft.perKm} suffix="R$" hint="Acrescentado por quilômetro estimado." min="0" max="1000" step="0.01" onChange={value => change('perKm', value)} disabled={busy} />
      <PricingField label="Valor mínimo da corrida" id="minimumFare" value={draft.minimumFare} suffix="R$" hint="Piso de preço da categoria Econômico." min="1" max="1000" step="0.01" onChange={value => change('minimumFare', value)} disabled={busy} />
      <PricingField label="Comissão da plataforma" id="commissionPercent" value={draft.commissionPercent} suffix="%" hint="Percentual sobre o valor da corrida." min="0" max="50" step="0.01" onChange={value => change('commissionPercent', value)} disabled={busy} />
      <PricingField label="Multiplicador Conforto" id="comfortMultiplier" value={draft.comfortMultiplier} suffix="×" hint="Aplicado ao preço da categoria Econômico." min="1" max="3" step="0.01" onChange={value => change('comfortMultiplier', value)} disabled={busy} />
    </div><div className="form-footer"><span><ShieldCheck size={15} /> Corridas já solicitadas mantêm o preço.</span><ActionButton type="submit" busy={busy} disabled={stale}><Check size={17} /> Salvar tarifas</ActionButton></div></form>
    <aside className="pricing-aside"><section className="pricing-preview"><span className="eyebrow light">SIMULAÇÃO DE TARIFA</span><div className="preview-icon"><CarFront size={36} /></div><h2>Um trajeto de 5 km</h2><p>Uma prévia com os valores deste formulário.</p><div className="preview-price"><span>Econômico</span><strong>{Number.isFinite(estimated) ? currency(estimated * 100) : '—'}</strong></div><div className="preview-price"><span>Conforto</span><strong>{Number.isFinite(estimated * Number(draft.comfortMultiplier)) ? currency(estimated * Number(draft.comfortMultiplier) * 100) : '—'}</strong></div><div className="preview-note"><CircleDollarSign size={16} /> Pagamento em dinheiro ao motorista</div></section><div className="info-note"><AlertCircle size={18} /><p>As distâncias são estimadas entre os pontos disponíveis. Navegação e roteamento de vias precisam de integração específica.</p></div></aside></div></>;
}
function PricingField({ label, id, suffix, hint, value, onChange, ...props }) {
  return <div className="pricing-field"><label htmlFor={id}>{label}</label><div className="number-input"><span>{suffix}</span><input id={id} type="number" required value={value} onChange={event => onChange(event.target.value)} {...props} /></div><small>{hint}</small></div>;
}

function RideDetails({ ride, onClose, onUpdate, notify }) {
  const [busy, setBusy] = useState(false); const [confirmCancel, setConfirmCancel] = useState(false); const closeRef = useRef(null); const dialogRef = useRef(null);
  useEffect(() => {
    const previousFocus = document.activeElement; closeRef.current?.focus();
    const onKey = event => {
      if (event.key === 'Escape') onClose();
      if (event.key === 'Tab') {
        const items = dialogRef.current?.querySelectorAll('button:not(:disabled), a[href], input, select, textarea, [tabindex="0"]');
        if (!items?.length) return;
        const first = items[0]; const last = items[items.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener('keydown', onKey); const before = document.body.style.overflow; document.body.style.overflow = 'hidden';
    const background = [...document.querySelectorAll('.main-shell, .sidebar')];
    background.forEach(node => node.setAttribute('inert', ''));
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = before; background.forEach(node => node.removeAttribute('inert')); previousFocus?.focus?.(); };
  }, [onClose]);
  async function cancel() {
    setBusy(true);
    try { await request(`/rides/${encodeURIComponent(ride.id)}/status`, { method: 'POST', body: { status: 'cancelled' } }); await onUpdate(); notify('Corrida cancelada. Passageiro e motorista receberão a atualização.'); setConfirmCancel(false); } catch (error) { notify(error.message, 'error'); } finally { setBusy(false); }
  }
  return <div className="drawer-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}><section ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby="ride-detail-title" className="ride-drawer"><div className="drawer-heading"><div><span className="eyebrow">DETALHES DA CORRIDA</span><h2 id="ride-detail-title">#{String(ride.id).slice(-6).toUpperCase()}</h2></div><button ref={closeRef} className="icon-button" aria-label="Fechar detalhes" onClick={onClose}><X size={22} /></button></div><div className="drawer-status"><Badge status={ride.status} /><span>{dateTime(ride.createdAt)}</span></div>
    <div className="drawer-route"><div><span className="route-origin-dot" /><div><small>EMBARQUE</small><strong>{ride.origin?.name}</strong><p>{ride.origin?.address}</p></div></div><div><MapPin size={18} /><div><small>DESTINO</small><strong>{ride.destination?.name}</strong><p>{ride.destination?.address}</p></div></div></div>
    <div className="ride-facts"><span><Route size={16} /><strong>{Number(ride.distanceKm || 0).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} km</strong><small>estimados</small></span><span><Clock3 size={16} /><strong>{ride.durationMinutes} min</strong><small>estimados</small></span><span><CarFront size={16} /><strong>{ride.category === 'comfort' ? 'Conforto' : 'Econômico'}</strong><small>categoria</small></span></div>
    <div className="detail-section"><h3>Pessoas da corrida</h3><div className="detail-person"><Avatar name={ride.riderName} color="sand" /><div><small>Passageiro</small><strong>{ride.riderName}</strong></div></div><div className="detail-person"><Avatar name={ride.driverName || 'Motorista'} /><div><small>Motorista parceiro</small><strong>{ride.driverName || 'Aguardando aceite'}</strong>{ride.driverVehicle && <p>{[ride.driverVehicle.model, ride.driverVehicle.plate].filter(Boolean).join(' · ')}</p>}</div></div></div>
    <div className="detail-section"><h3>Valores da corrida</h3><div className="detail-money"><span>Total</span><strong>{currency(ride.totalCents)}</strong></div><div className="detail-money"><span>Comissão da plataforma</span><strong>{currency(ride.commissionCents)}</strong></div><div className="detail-money"><span>Valor do motorista</span><strong>{currency(ride.totalCents - ride.commissionCents)}</strong></div><span className="payment-caption"><CircleDollarSign size={15} /> Pagamento em dinheiro</span>{ride.rating && <div className="rating-display"><Star size={17} />{ride.rating}/5 <span>Avaliação do passageiro</span></div>}</div>
    {activeStatuses.includes(ride.status) && <div className="drawer-actions">{confirmCancel ? <><div className="error-message"><AlertCircle size={18} />Cancelar esta corrida para todos os participantes?</div><div className="confirmation-buttons"><button className="button subtle" onClick={() => setConfirmCancel(false)} disabled={busy}>Manter corrida</button><ActionButton className="button danger" busy={busy} onClick={cancel}>Confirmar cancelamento</ActionButton></div></> : <button className="button danger-outline" onClick={() => setConfirmCancel(true)}><Ban size={16} /> Cancelar corrida</button>}</div>}
    <p className="detail-updated">Atualizada em {dateTime(ride.updatedAt)}</p>
  </section></div>;
}

export default function App() {
  const [user, setUser] = useState(null); const [dashboard, setDashboard] = useState(null); const [booting, setBooting] = useState(true); const [demoMode, setDemoMode] = useState(false);
  const [page, setPage] = useState('overview'); const [sidebarOpen, setSidebarOpen] = useState(false); const [sync, setSync] = useState('polling'); const [loadError, setLoadError] = useState('');
  const [selectedId, setSelectedId] = useState(null); const [toast, setToast] = useState(null); const [refreshing, setRefreshing] = useState(false);
  const requestsRef = useRef(new Set()); const toastTimer = useRef(null); const userRef = useRef(null);
  const dashboardSequence = useRef(0); const sidebarRef = useRef(null); const menuButtonRef = useRef(null);
  const notify = useCallback((message, type = 'success') => { setToast({ message, type }); clearTimeout(toastTimer.current); toastTimer.current = setTimeout(() => setToast(null), 6500); }, []);
  const clearSession = useCallback(() => {
    userRef.current = null; dashboardSequence.current += 1; requestsRef.current.forEach(controller => controller.abort()); requestsRef.current.clear();
    setUser(null); setDashboard(null); setSelectedId(null); setPage('overview'); setSidebarOpen(false); setSync('polling'); setLoadError('');
  }, []);
  const loadDashboard = useCallback(async () => {
    if (!userRef.current) return;
    const currentUser = userRef.current;
    const sequence = ++dashboardSequence.current;
    const controller = new AbortController(); requestsRef.current.add(controller);
    try {
      const result = await request('/dashboard', { signal: controller.signal });
      if (controller.signal.aborted || sequence !== dashboardSequence.current || userRef.current !== currentUser) return;
      if (result.user?.role !== 'admin') {
        clearSession(); notify('Este painel é exclusivo do superadmin.', 'error'); return;
      }
      setDashboard(result); setLoadError('');
    } catch (error) {
      if (error.name === 'AbortError' || sequence !== dashboardSequence.current || userRef.current !== currentUser) return;
      if (error.status === 401 || error.status === 403) { clearSession(); notify('Sua sessão expirou. Entre novamente.', 'error'); }
      else setLoadError(error.message);
    } finally { requestsRef.current.delete(controller); }
  }, [clearSession, notify]);
  useEffect(() => {
    let alive = true; const controller = new AbortController();
    Promise.allSettled([request('/meta', { signal: controller.signal }), request('/auth/me', { signal: controller.signal })]).then(results => {
      if (!alive) return;
      if (results[0].status === 'fulfilled') setDemoMode(Boolean(results[0].value.demoMode));
      if (results[1].status === 'fulfilled') {
        const next = results[1].value.user;
        if (next?.role === 'admin') { userRef.current = next; setUser(next); }
      }
      setBooting(false);
    });
    return () => { alive = false; controller.abort(); };
  }, []);
  useEffect(() => {
    if (!user) return;
    loadDashboard();
    const stream = typeof EventSource !== 'undefined' ? new EventSource('/api/events') : null;
    if (stream) {
      stream.onopen = () => setSync('live'); stream.onerror = () => setSync('polling'); stream.addEventListener('change', loadDashboard);
    }
    const polling = setInterval(() => { if (document.visibilityState === 'visible') loadDashboard(); }, 15000);
    const onVisible = () => { if (document.visibilityState === 'visible') loadDashboard(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => { stream?.close(); clearInterval(polling); document.removeEventListener('visibilitychange', onVisible); requestsRef.current.forEach(controller => controller.abort()); requestsRef.current.clear(); };
  }, [user, loadDashboard]);
  useEffect(() => () => clearTimeout(toastTimer.current), []);
  useEffect(() => { setSidebarOpen(false); }, [page]);
  useEffect(() => {
    if (!sidebarOpen) return;
    const panel = sidebarRef.current;
    const main = document.querySelector('.main-shell');
    const previousFocus = document.activeElement;
    const before = document.body.style.overflow;
    main?.setAttribute('inert', '');
    document.body.style.overflow = 'hidden';
    panel?.querySelector('button[aria-label="Fechar menu"]')?.focus();
    const onKey = event => {
      if (event.key === 'Escape') { event.preventDefault(); setSidebarOpen(false); }
      if (event.key !== 'Tab') return;
      const focusable = [...panel.querySelectorAll('button:not(:disabled), a[href]')].filter(node => node.getClientRects().length);
      const first = focusable[0]; const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    };
    document.addEventListener('keydown', onKey);
    return () => { main?.removeAttribute('inert'); document.body.style.overflow = before; document.removeEventListener('keydown', onKey); (previousFocus || menuButtonRef.current)?.focus?.(); };
  }, [sidebarOpen]);
  async function login(email, password) {
    const result = await request('/auth/login', { method: 'POST', body: { email, password } });
    if (result.user.role !== 'admin') { await request('/auth/logout', { method: 'POST', body: {} }); throw new Error('Este painel é exclusivo do superadmin. Passageiros e motoristas devem usar o aplicativo.'); }
    userRef.current = result.user; setUser(result.user);
  }
  async function logout() {
    try { await request('/auth/logout', { method: 'POST', body: {} }); clearSession(); } catch (error) { notify(`Não foi possível encerrar a sessão: ${error.message}`, 'error'); }
  }
  async function refresh() { setRefreshing(true); await loadDashboard(); setRefreshing(false); }
  const closeDetails = useCallback(() => setSelectedId(null), []);
  const selectedRide = dashboard?.rides.find(ride => ride.id === selectedId);
  const pending = dashboard?.users.filter(person => person.role === 'driver' && !person.approved).length || 0;
  if (booting) return <div className="app-loading"><Brand /><LoaderCircle className="spin" size={25} /><p>Preparando sua central…</p></div>;
  if (!user) return <><Login demoMode={demoMode} onLogin={login} />{toast && <Toast toast={toast} onClose={() => setToast(null)} />}</>;
  return <div className="app-shell">
    {sidebarOpen && <div className="sidebar-scrim" onClick={() => setSidebarOpen(false)} />}
    <aside ref={sidebarRef} className={`sidebar ${sidebarOpen ? 'is-open' : ''}`} role={sidebarOpen ? 'dialog' : undefined} aria-modal={sidebarOpen || undefined} aria-label="Menu da operação"><div className="sidebar-brand"><Brand light /><button className="icon-button mobile-close" aria-label="Fechar menu" onClick={() => setSidebarOpen(false)}><X size={20} /></button></div><div className="workspace-label"><span><Gauge size={18} /></span><div><strong>Central de operação</strong><small>Superadmin</small></div><ChevronRight size={14} /></div>
      <span className="nav-label">PRINCIPAL</span><nav aria-label="Navegação principal">{navItems.map(({ id, label, Icon }) => <button key={id} className={`nav-item ${page === id ? 'active' : ''}`} aria-current={page === id ? 'page' : undefined} onClick={() => { setPage(id); setSidebarOpen(false); }}><Icon size={19} /><span>{label}</span>{id === 'drivers' && pending > 0 && <b className="nav-count">{pending}</b>}{page === id && <span className="nav-active-dot" />}</button>)}</nav>
      <div className="sidebar-bottom"><div className="sidebar-note"><span className="sidebar-note-icon"><Navigation size={22} /></span><strong>Uma cidade. Muitas conexões.</strong><p>Sua operação acontece em conjunto, a cada nova corrida.</p><span><i /> REA Mobilidade</span></div><div className="sidebar-user"><Avatar name={user.name} /><div><strong>{user.name}</strong><small>Administrador</small></div><button className="icon-button" aria-label="Sair da conta" title="Sair" onClick={logout}><LogOut size={18} /></button></div></div>
    </aside>
    <div className="main-shell"><header className="topbar"><div className="topbar-left"><button ref={menuButtonRef} className="icon-button mobile-menu" aria-label="Abrir menu" aria-expanded={sidebarOpen} onClick={() => setSidebarOpen(true)}><Menu size={22} /></button><span className="breadcrumb">Operação <ChevronRight size={13} /><strong>{navItems.find(item => item.id === page)?.label}</strong></span></div><div className="topbar-right"><span className={`sync-status ${sync === 'live' ? '' : 'sync-polling'}`}><i />{sync === 'live' ? 'Sincronizado' : 'Atualização periódica'}</span><span className="topbar-divider" /><button className="icon-button notification-button" aria-label={`${pending} motoristas aguardando aprovação`} title="Cadastros pendentes" onClick={() => setPage('drivers')}><Bell size={19} />{pending > 0 && <i />}</button><Avatar name={user.name} small /></div></header>
    <main className="main-content" id="main-content">{demoMode && <div className="demo-banner"><span className="demo-indicator" /> Demonstração local <span>Contas e corridas de teste</span></div>}
    <div className="date-line"><MapPin size={13} /><span>São Paulo, Brasil</span><span className="date-separator">/</span><span>{new Intl.DateTimeFormat('pt-BR', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'America/Sao_Paulo' }).format(new Date())}</span></div>
    {loadError && <div className="load-error" role="alert"><AlertCircle size={18} /><span>{loadError}</span><ActionButton busy={refreshing} className="text-button" onClick={refresh}>Tentar novamente <RefreshCw size={15} /></ActionButton></div>}
    {!dashboard ? <div className="dashboard-loading"><LoaderCircle className="spin" size={28} /><h2>Carregando a operação</h2><p>Buscando corridas, parceiros e passageiros.</p></div> : <>
      {page === 'overview' && <Overview dashboard={dashboard} setPage={setPage} onSelect={ride => setSelectedId(ride.id)} />}
      {page === 'rides' && <Rides rides={dashboard.rides} onSelect={ride => setSelectedId(ride.id)} />}
      {(page === 'drivers' || page === 'riders') && <People key={page} dashboard={dashboard} kind={page === 'drivers' ? 'driver' : 'rider'} onUpdate={loadDashboard} notify={notify} />}
      {page === 'settings' && <Pricing settings={dashboard.settings} onUpdate={loadDashboard} notify={notify} />}
    </>}
    </main></div>
    {selectedRide && <RideDetails ride={selectedRide} onClose={closeDetails} onUpdate={loadDashboard} notify={notify} />}
    {toast && <Toast toast={toast} onClose={() => setToast(null)} />}
  </div>;
}
function Toast({ toast, onClose }) {
  return <div className={`toast toast-${toast.type}`} role={toast.type === 'error' ? 'alert' : 'status'}>{toast.type === 'error' ? <AlertCircle size={20} /> : <CheckCircle2 size={20} />}<span>{toast.message}</span><button className="icon-button" aria-label="Fechar aviso" onClick={onClose}><X size={16} /></button></div>;
}
