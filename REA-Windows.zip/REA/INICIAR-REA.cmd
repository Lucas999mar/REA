@echo off
call "%~dp0scripts\start-demo.cmd"
exit /b %errorlevel%
