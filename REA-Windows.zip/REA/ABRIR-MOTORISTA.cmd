@echo off
call "%~dp0scripts\start-mobile.cmd" driver
exit /b %errorlevel%
