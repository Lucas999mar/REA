import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { once } from 'node:events';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createApp } from '../server/index.js';

async function fixture(t, { demoMode = true } = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'rea-api-test-'));
  const service = createApp({ dbPath: join(dir, 'test.sqlite'), demoMode });
  const server = service.app.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const base = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => { server.closeAllConnections(); await new Promise((resolve) => server.close(resolve)); service.close(); rmSync(dir, { recursive: true, force: true }); });
  const call = async (path, { token, cookie, headers = {}, ...options } = {}) => {
    const response = await fetch(`${base}/api${path}`, { ...options, headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}), ...(cookie ? { cookie } : {}), ...headers }, body: options.body === undefined ? undefined : JSON.stringify(options.body) });
    const data = await response.json();
    return { status: response.status, data, cookie: response.headers.get('set-cookie') };
  };
  const login = async (email, mobile = true) => {
    const result = await call('/auth/login', { method: 'POST', headers: mobile ? { 'x-client-type': 'mobile' } : {}, body: { email, password: 'ReaDemo!2026' } });
    assert.equal(result.status, 200, JSON.stringify(result.data));
    return { ...result.data, cookie: result.cookie };
  };
  return { ...service, dir, base, call, login, server };
}
const route = { originId: 'paulista', destinationId: 'ibirapuera', category: 'economy', paymentMethod: 'cash' };
const vehicle = { model: 'Fiat Cronos', plate: 'ABC1D23', color: 'Branco' };

// The same persisted ride is observed independently by all three clients.
test('passageiro, motorista e superadmin compartilham o ciclo completo da corrida', async (t) => {
  const { call, login } = await fixture(t);
  const rider = await login('passageiro@rea.local');
  const driver = await login('motorista@rea.local');
  const admin = await login('admin@rea.local');
  const created = await call('/rides', { method: 'POST', token: rider.token, body: { ...route, totalCents: 1 } });
  assert.equal(created.status, 201);
  const id = created.data.ride.id;
  assert.ok(created.data.ride.totalCents >= 1000, 'fare must be computed on the server');
  const available = await call('/dashboard', { token: driver.token });
  assert.ok(available.data.availableRides.some((ride) => ride.id === id));
  const accepted = await call(`/rides/${id}/accept`, { method: 'POST', token: driver.token, body: {} });
  assert.equal(accepted.data.ride.status, 'accepted');
  assert.equal(accepted.data.ride.driverId, driver.user.id);
  for (const status of ['arrived', 'in_progress', 'completed']) {
    const response = await call(`/rides/${id}/status`, { method: 'POST', token: driver.token, body: { status } });
    assert.equal(response.status, 200, JSON.stringify(response.data));
    for (const actor of [rider, driver, admin]) {
      const dashboard = await call('/dashboard', { token: actor.token });
      assert.equal(dashboard.data.rides.find((ride) => ride.id === id).status, status);
    }
  }
  const rating = await call(`/rides/${id}/rating`, { method: 'POST', token: rider.token, body: { rating: 5 } });
  assert.equal(rating.data.ride.rating, 5);
  assert.equal((await call(`/rides/${id}/rating`, { method: 'POST', token: rider.token, body: { rating: 4 } })).status, 409);
  const stats = (await call('/dashboard', { token: admin.token })).data.stats;
  assert.equal(stats.completedRides, 9);
  assert.ok(stats.totalRevenueCents > stats.driverEarningsCents);
});

test('autorização limita perfis e impede leitura e alteração de corrida de terceiros', async (t) => {
  const { call, login } = await fixture(t);
  const rider = await login('passageiro@rea.local');
  const stranger = await call('/auth/register', { method: 'POST', headers: { 'x-client-type': 'mobile' }, body: { name: 'Outro Passageiro', email: 'outro@example.test', password: 'LongPassword!1', role: 'rider' } });
  assert.equal(stranger.status, 201);
  const token = stranger.data.token;
  const created = await call('/rides', { method: 'POST', token: rider.token, body: route });
  const id = created.data.ride.id;
  assert.equal((await call('/dashboard', { token })).data.rides.length, 0);
  assert.deepEqual((await call('/dashboard', { token })).data.users, []);
  assert.equal((await call(`/rides/${id}/status`, { method: 'POST', token, body: { status: 'cancelled' } })).status, 403);
  assert.equal((await call(`/rides/${id}/accept`, { method: 'POST', token: rider.token, body: {} })).status, 403);
  assert.equal((await call('/admin/settings', { method: 'PATCH', token: rider.token, body: { commissionPercent: 0 } })).status, 403);
  assert.equal((await call('/auth/register', { method: 'POST', body: { name: 'Fake admin', email: 'evil@example.test', password: 'LongPassword!1', role: 'admin' } })).status, 400);
  assert.equal((await call('/dashboard')).status, 401);
});

test('motorista pendente exige aprovação e aceitação simultânea tem um único vencedor', async (t) => {
  const { call, login } = await fixture(t);
  const rider = await login('passageiro@rea.local');
  const driver = await login('motorista@rea.local');
  const admin = await login('admin@rea.local');
  const registered = await call('/auth/register', { method: 'POST', headers: { 'x-client-type': 'mobile' }, body: { name: 'Novo Motorista', email: 'novo@example.test', password: 'LongPassword!1', role: 'driver', vehicle } });
  const other = registered.data;
  assert.equal(registered.status, 201);
  assert.equal(other.user.approved, false);
  assert.equal((await call('/driver/availability', { method: 'POST', token: other.token, body: { online: true } })).status, 403);
  assert.equal((await call(`/admin/users/${other.user.id}`, { method: 'PATCH', token: admin.token, body: { approved: true } })).status, 200);
  assert.equal((await call('/driver/availability', { method: 'POST', token: other.token, body: { online: true } })).status, 200);
  const created = await call('/rides', { method: 'POST', token: rider.token, body: route });
  assert.equal((await call('/rides', { method: 'POST', token: rider.token, body: route })).status, 409);
  const id = created.data.ride.id;
  const results = await Promise.all([driver, other].map((actor) => call(`/rides/${id}/accept`, { method: 'POST', token: actor.token, body: {} })));
  assert.deepEqual(results.map((result) => result.status).sort(), [200, 409]);
  const winner = results[0].status === 200 ? driver : other;
  assert.equal((await call('/driver/availability', { method: 'POST', token: winner.token, body: { online: false } })).status, 409);
  assert.equal((await call(`/admin/users/${winner.user.id}`, { method: 'PATCH', token: admin.token, body: { approved: false } })).status, 409);
  assert.equal((await call(`/rides/${id}/status`, { method: 'POST', token: winner.token, body: { status: 'completed' } })).status, 409);
  assert.equal((await call(`/rides/${id}/status`, { method: 'POST', token: rider.token, body: { status: 'arrived' } })).status, 403);
  assert.equal((await call(`/rides/${id}/status`, { method: 'POST', token: rider.token, body: { status: 'cancelled' } })).status, 200);
  assert.equal((await call(`/rides/${id}/status`, { method: 'POST', token: winner.token, body: { status: 'arrived' } })).status, 409);
});

test('sessões web usam cookie HttpOnly, tokens persistem no banco e logout os revoga', async (t) => {
  const { call, login, dir, db } = await fixture(t);
  const web = await login('admin@rea.local', false);
  assert.equal(web.token, undefined);
  assert.match(web.cookie, /HttpOnly/);
  assert.match(web.cookie, /SameSite=Strict/);
  assert.equal((await call('/auth/me', { cookie: web.cookie.split(';')[0] })).data.user.role, 'admin');
  const mobile = await login('passageiro@rea.local');
  const stored = db.prepare('SELECT token_hash FROM sessions').all();
  assert.ok(stored.every((session) => session.token_hash !== mobile.token));
  assert.throws(() => createApp({ dbPath: join(dir, 'test.sqlite'), demoMode: false }), /contas demonstrativas/);
  const reopened = createApp({ dbPath: join(dir, 'test.sqlite'), demoMode: true });
  const secondServer = reopened.app.listen(0, '127.0.0.1');
  await once(secondServer, 'listening');
  try {
    const response = await fetch(`http://127.0.0.1:${secondServer.address().port}/api/auth/me`, { headers: { authorization: `Bearer ${mobile.token}` } });
    assert.equal(response.status, 200);
    assert.equal((await response.json()).user.id, mobile.user.id);
  } finally {
    secondServer.closeAllConnections();
    await new Promise((resolve) => secondServer.close(resolve));
    reopened.close();
  }
  assert.equal((await call('/auth/logout', { method: 'POST', token: mobile.token, body: {} })).status, 200);
  assert.equal((await call('/auth/me', { token: mobile.token })).status, 401);
  assert.equal((await call('/auth/login', { method: 'POST', headers: { origin: 'https://untrusted.example' }, body: { email: 'admin@rea.local', password: 'ReaDemo!2026' } })).status, 403);
});

test('tarifas novas não alteram corridas existentes e coordenadas inválidas são recusadas', async (t) => {
  const { call, login } = await fixture(t);
  const admin = await login('admin@rea.local');
  const rider = await login('passageiro@rea.local');
  const driver = await login('motorista@rea.local');
  const created = await call('/rides', { method: 'POST', token: rider.token, body: route });
  const previous = created.data.ride.totalCents;
  assert.equal((await call('/admin/settings', { method: 'PATCH', token: admin.token, body: { perKmCents: 600 } })).status, 200);
  const next = await call('/quotes', { method: 'POST', token: rider.token, body: route });
  assert.ok(next.data.quote.totalCents > previous);
  assert.equal((await call('/dashboard', { token: rider.token })).data.rides.find((ride) => ride.id === created.data.ride.id).totalCents, previous);
  assert.equal((await call('/admin/settings', { method: 'PATCH', token: admin.token, body: { commissionPercent: 101 } })).status, 400);
  assert.equal((await call('/driver/location', { method: 'POST', token: driver.token, body: { lat: 999, lng: 0 } })).status, 400);
  assert.equal((await call('/driver/location', { method: 'POST', token: driver.token, body: { lat: -23.5614, lng: -46.6559 } })).status, 200);
});

test('modo padrão não cria contas demonstrativas', async (t) => {
  const { call, db, dir } = await fixture(t, { demoMode: false });
  assert.equal(db.prepare('SELECT COUNT(*) AS count FROM users').get().count, 0);
  assert.deepEqual((await call('/meta')).data, { demoMode: false });
  assert.equal((await call('/auth/login', { method: 'POST', body: { email: 'admin@rea.local', password: 'ReaDemo!2026' } })).status, 401);
  const registered = await call('/auth/register', { method: 'POST', body: { name: 'Pessoa Real', email: 'real@example.test', password: 'LongPassword!1', role: 'rider' } });
  assert.equal(registered.status, 201);
  assert.throws(() => createApp({ dbPath: join(dir, 'test.sqlite'), demoMode: true }), /contas reais/);
  assert.equal(db.prepare('SELECT COUNT(*) AS count FROM users').get().count, 1);
});


test('SSE entrega alterações do ciclo sem expor payloads pessoais ou tokens', async (t) => {
  const { call, login, base } = await fixture(t);
  const admin = await login('admin@rea.local');
  const rider = await login('passageiro@rea.local');
  const controller = new AbortController();
  const response = await fetch(`${base}/api/events`, { headers: { authorization: `Bearer ${admin.token}` }, signal: controller.signal });
  assert.equal(response.status, 200);
  assert.match(response.headers.get('content-type'), /text\/event-stream/);
  const reader = response.body.getReader();
  try {
    const initial = await reader.read();
    assert.match(new TextDecoder().decode(initial.value), /connected/);
    const created = await call('/rides', { method: 'POST', token: rider.token, body: route });
    assert.equal(created.status, 201);
    const event = new TextDecoder().decode((await reader.read()).value);
    assert.match(event, /event: change/);
    assert.match(event, /\{"type":"ride"\}/);
    assert.ok(!event.includes(rider.user.email));
    assert.ok(!event.includes(rider.token));
  } finally { controller.abort(); await reader.cancel().catch(() => {}); }
});

test('localização só aparece para o passageiro da corrida ativa e deixa de aparecer após conclusão', async (t) => {
  const { call, login } = await fixture(t);
  const rider = await login('passageiro@rea.local');
  const driver = await login('motorista@rea.local');
  const stranger = await call('/auth/register', { method: 'POST', headers: { 'x-client-type': 'mobile' }, body: { name: 'Outro Passageiro', email: 'outro@example.test', password: 'LongPassword!1', role: 'rider' } });
  const created = await call('/rides', { method: 'POST', token: rider.token, body: route });
  const id = created.data.ride.id;
  assert.equal((await call(`/rides/${id}/accept`, { method: 'POST', token: driver.token, body: {} })).status, 200);
  const location = { lat: -23.56, lng: -46.65 };
  assert.equal((await call('/driver/location', { method: 'POST', token: driver.token, body: location })).status, 200);
  assert.deepEqual((await call('/dashboard', { token: rider.token })).data.rides.find((ride) => ride.id === id).driverLocation, location);
  assert.deepEqual((await call('/dashboard', { token: stranger.data.token })).data.rides, []);
  for (const status of ['arrived', 'in_progress']) assert.equal((await call(`/rides/${id}/status`, { method: 'POST', token: driver.token, body: { status } })).status, 200);
  assert.equal((await call(`/rides/${id}/status`, { method: 'POST', token: rider.token, body: { status: 'cancelled' } })).status, 409);
  assert.equal((await call(`/rides/${id}/status`, { method: 'POST', token: driver.token, body: { status: 'cancelled' } })).status, 409);
  assert.equal((await call(`/rides/${id}/status`, { method: 'POST', token: driver.token, body: { status: 'completed' } })).status, 200);
  const history = (await call('/dashboard', { token: rider.token })).data.rides;
  assert.ok(history.every((ride) => ride.driverLocation === null));
});

test('bootstrap cria administrador sem publicar senha e recusa sobrescrever uma conta existente', async (t) => {
  const dir = mkdtempSync(join(tmpdir(), 'rea-admin-test-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const script = fileURLToPath(new URL('../server/create-admin.js', import.meta.url));
  const run = (password) => spawnSync(process.execPath, [script], { encoding: 'utf8', env: { ...process.env, DATA_DIR: dir, ADMIN_EMAIL: 'owner@example.test', ADMIN_PASSWORD: password, ADMIN_NAME: 'Owner' } });
  const invalid = run('too-short');
  assert.equal(invalid.status, 1);
  const password = 'AdminExample!2026';
  const first = run(password);
  assert.equal(first.status, 0, first.stderr);
  assert.ok(!`${first.stdout}${first.stderr}`.includes(password));
  assert.equal(run('DifferentPassword!2026').status, 1);
  const service = createApp({ dbPath: join(dir, 'rea.sqlite') });
  try {
    const user = service.db.prepare('SELECT * FROM users WHERE email=?').get('owner@example.test');
    assert.equal(user.role, 'admin');
    assert.equal(user.approved, 1);
    assert.match(user.password_hash, /^scrypt\$/);
    assert.notEqual(user.password_hash, password);
  } finally { service.close(); }
});

test('SIGTERM encerra o servidor mesmo com SSE ativo', { timeout: 10_000 }, async (t) => {
  const dir = mkdtempSync(join(tmpdir(), 'rea-stop-test-'));
  const child = spawn(process.execPath, [fileURLToPath(new URL('../server/index.js', import.meta.url))], { env: { ...process.env, DATA_DIR: dir, PORT: '0', HOST: '127.0.0.1', REA_DEMO_MODE: '1' }, stdio: ['ignore', 'pipe', 'pipe'] });
  const exit = once(child, 'exit');
  const controller = new AbortController();
  t.after(async () => {
    controller.abort();
    if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL');
    await exit;
    rmSync(dir, { recursive: true, force: true });
  });
  let output = '';
  const base = await new Promise((resolve, reject) => {
    child.once('error', reject);
    child.once('exit', () => reject(new Error('Server stopped before readiness')));
    child.stdout.on('data', (chunk) => {
      output += chunk.toString();
      const match = output.match(/REA API em 127\.0\.0\.1:(\d+)/);
      if (match) resolve(`http://127.0.0.1:${match[1]}`);
    });
  });
  const login = await fetch(`${base}/api/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-client-type': 'mobile' }, body: JSON.stringify({ email: 'admin@rea.local', password: 'ReaDemo!2026' }) });
  const { token } = await login.json();
  const events = await fetch(`${base}/api/events`, { headers: { authorization: `Bearer ${token}` }, signal: controller.signal });
  assert.equal(events.status, 200);
  const reader = events.body.getReader();
  await reader.read();
  child.kill('SIGTERM');
  const [code, signal] = await exit;
  assert.equal(code, 0);
  assert.equal(signal, null);
  await reader.cancel();
});

test('porta ocupada encerra a nova instância com erro legível e preserva o servidor existente', async (t) => {
  const { base, call } = await fixture(t, { demoMode: false });
  const dir = mkdtempSync(join(tmpdir(), 'rea-port-test-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const result = spawnSync(process.execPath, [fileURLToPath(new URL('../server/index.js', import.meta.url))], {
    encoding: 'utf8',
    timeout: 5000,
    env: { ...process.env, DATA_DIR: dir, PORT: new URL(base).port, HOST: '127.0.0.1', REA_DEMO_MODE: '0' },
  });
  assert.equal(result.error, undefined);
  assert.equal(result.status, 1);
  assert.equal(result.signal, null);
  assert.match(result.stderr, /Não foi possível iniciar REA.*já está em uso \(EADDRINUSE\)/);
  assert.ok(!result.stderr.includes('TypeError'));
  assert.ok(!result.stdout.includes('REA API em'));
  assert.deepEqual((await call('/health')).data, { ok: true });
});
