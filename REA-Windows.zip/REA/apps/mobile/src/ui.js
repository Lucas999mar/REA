import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';

export const colors = { ink: '#153B36', teal: '#145B4E', mint: '#E4F0E9', cream: '#F7F6F0', muted: '#73817A', border: '#E5E8DE', gold: '#D79C36', white: '#FFFFFF', red: '#A14236' };

export function Button({ title, onPress, secondary, danger, disabled, loading, style }) {
  return <Pressable accessibilityRole="button" accessibilityLabel={title} disabled={disabled || loading} onPress={onPress}
    style={({ pressed }) => [s.button, secondary && s.secondary, danger && s.danger, (disabled || loading) && { opacity: .5 }, pressed && { opacity: .8 }, style]}>
    {loading ? <ActivityIndicator color={secondary ? colors.teal : colors.white} /> : <Text style={[s.buttonText, secondary && { color: colors.teal }, danger && { color: colors.red }]}>{title}</Text>}
  </Pressable>;
}
export function Field({ label, ...props }) {
  return <View style={s.field}><Text style={s.fieldLabel}>{label}</Text><TextInput accessibilityLabel={label} placeholderTextColor="#96A19A" {...props} style={[s.input, props.style]} /></View>;
}
export function Card({ children, style }) { return <View style={[s.card, style]}>{children}</View>; }
export function Label({ children, style }) { return <Text style={[s.label, style]}>{children}</Text>; }
export function Title({ children, style }) { return <Text style={[s.title, style]}>{children}</Text>; }
export function Body({ children, style }) { return <Text style={[s.body, style]}>{children}</Text>; }
export function Badge({ children, tone = 'green' }) {
  return <View style={[s.badge, { backgroundColor: tone === 'gold' ? '#FFF2D7' : tone === 'gray' ? '#EFF0EB' : colors.mint }]}>
    <Text style={[s.badgeText, { color: tone === 'gold' ? '#8F651B' : colors.teal }]}>{children}</Text>
  </View>;
}
export function Route({ origin, destination, compact }) {
  return <View style={{ gap: compact ? 12 : 20 }}>
    <View style={s.routeRow}><View style={s.originDot}/><View style={{ flex: 1 }}><Label>EMBARQUE</Label><Text style={s.placeName}>{origin?.name || 'Origem'}</Text>{!compact && <Body>{origin?.address}</Body>}</View></View>
    <View style={s.routeRow}><View style={s.destinationDot}/><View style={{ flex: 1 }}><Label>DESTINO</Label><Text style={s.placeName}>{destination?.name || 'Destino'}</Text>{!compact && <Body>{destination?.address}</Body>}</View></View>
  </View>;
}
export const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.cream },
  content: { padding: 24, paddingBottom: 32, gap: 20 },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  card: { backgroundColor: colors.white, borderRadius: 24, padding: 22, borderWidth: 1, borderColor: colors.border, gap: 18 },
  label: { color: colors.muted, fontWeight: '700', fontSize: 10, letterSpacing: 1.5, marginBottom: 5 },
  title: { color: colors.ink, fontWeight: '700', fontSize: 27, lineHeight: 34, letterSpacing: -.7 },
  body: { color: colors.muted, fontSize: 13, lineHeight: 20 },
  button: { minHeight: 52, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 18, paddingVertical: 14, backgroundColor: colors.teal, borderRadius: 14 },
  buttonText: { color: colors.white, fontSize: 15, fontWeight: '700' },
  secondary: { backgroundColor: colors.mint },
  danger: { backgroundColor: '#F8EBE7' },
  field: { gap: 7 },
  fieldLabel: { color: colors.ink, fontSize: 12, fontWeight: '600' },
  input: { backgroundColor: '#F7F8F4', color: colors.ink, borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 13, minHeight: 49, fontSize: 14 },
  badge: { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20 },
  badgeText: { fontSize: 10, fontWeight: '700' },
  routeRow: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  originDot: { height: 12, width: 12, borderRadius: 6, borderWidth: 3, borderColor: colors.teal },
  destinationDot: { height: 12, width: 12, borderRadius: 3, backgroundColor: colors.gold },
  placeName: { color: colors.ink, fontSize: 15, fontWeight: '600', lineHeight: 22 },
  sectionTitle: { fontSize: 19, color: colors.ink, fontWeight: '700' },
  divider: { height: 1, backgroundColor: colors.border },
  metric: { color: colors.ink, fontWeight: '700', fontSize: 31, letterSpacing: -1 },
});
