import Constants from 'expo-constants';

export const variant = Constants.expoConfig?.extra?.variant === 'driver' ? 'driver' : 'rider';
export const API_URL = (process.env.EXPO_PUBLIC_API_URL || Constants.expoConfig?.extra?.apiUrl || 'http://127.0.0.1:3001').replace(/\/$/, '');
export const demoEnabled = process.env.EXPO_PUBLIC_DEMO_MODE === '1';
export const sessionKey = `rea-session-${variant}`;

export class ApiError extends Error {
  constructor(message, status) { super(message); this.status = status; }
}

export async function request(path, { method = 'GET', body, token, signal } = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  const cancel = () => controller.abort();
  signal?.addEventListener('abort', cancel);
  if (signal?.aborted) controller.abort();
  try {
    const response = await fetch(`${API_URL}/api${path}`, {
      method,
      headers: {
        'Content-Type': 'application/json',
        'X-Client-Type': 'mobile',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
      signal: controller.signal,
    });
    let result;
    try { result = await response.json(); }
    catch { throw new ApiError('O servidor enviou uma resposta inesperada.', response.status); }
    if (!response.ok) throw new ApiError(result.error || 'Não foi possível concluir a operação.', response.status);
    return result;
  } catch (error) {
    if (signal?.aborted) {
      const cancelled = new Error('Requisição cancelada.');
      cancelled.name = 'AbortError';
      throw cancelled;
    }
    if (error instanceof ApiError) throw error;
    throw new ApiError(error.name === 'AbortError'
      ? 'A conexão demorou. Confira sua internet e tente novamente.'
      : 'Sem conexão com o servidor. Confira a internet e o endereço da API.', 0);
  } finally {
    clearTimeout(timeout);
    signal?.removeEventListener('abort', cancel);
  }
}

export const money = (cents = 0) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(cents / 100);
export const activeStatuses = ['requested', 'accepted', 'arrived', 'in_progress'];
export const statusLabel = {
  requested: 'Buscando motorista', accepted: 'Motorista a caminho', arrived: 'Motorista chegou',
  in_progress: 'Em viagem', completed: 'Concluída', cancelled: 'Cancelada',
};
