# REA Passageiro e REA Motorista

Dois aplicativos Android/iOS compartilham o código React Native com Expo. A variante seleciona o perfil, nome e identificador nativo; os dois acessam a mesma API do superadmin. Não é necessário copiar o código para criar o segundo aplicativo.

**Windows e celular Android:** use os atalhos da raiz do projeto conforme [o guia para abrir os apps](../../docs/ABRIR-APPS-ANDROID.md). Os comandos com `export` e variáveis antes do comando, abaixo, são para shells POSIX; os atalhos Windows configuram as variáveis sem essa sintaxe.

| Variante | Aplicativo | Android / iOS |
| --- | --- | --- |
| `rider` | REA Passageiro | `com.reamobilidade.passageiro` |
| `driver` | REA Motorista | `com.reamobilidade.motorista` |

## Desenvolvimento

Use o Node indicado na raiz do projeto. Instale as dependências e inicie a API conforme o README da raiz. Em outro terminal:

```bash
cd /workspace/REA/apps/mobile
export EXPO_NO_TELEMETRY=1
npm ci
EXPO_PUBLIC_API_URL=http://127.0.0.1:3001 npm run start:rider
# Para o segundo app, encerre o primeiro Metro e execute:
EXPO_PUBLIC_API_URL=http://127.0.0.1:3001 npm run start:driver
```

O endereço padrão `127.0.0.1` sempre aponta para o dispositivo que está executando o app. No emulador Android, o servidor no computador costuma ser acessível por `http://10.0.2.2:3001`. Em aparelho físico, configure `EXPO_PUBLIC_API_URL` com um endereço alcançável pelo aparelho; a máquina na nuvem não está automaticamente acessível pelo IP da sua rede local. Use um servidor de desenvolvimento acessível e uma rota de rede autorizada.

Para uma API executada no seu próprio computador e acessível pela rede local de desenvolvimento, inicie-a com `HOST=0.0.0.0` e use o IP desse computador. Faça isso somente em uma rede de desenvolvimento controlada. O endereço de produção deve usar HTTPS. As políticas de rede do Android/iOS podem bloquear HTTP em builds nativos; não foi desativada a verificação de TLS.

O Expo Go, quando compatível com o SDK instalado, permite exercitar a interface. Os aplicativos instaláveis separados exigem builds próprios. Ao trocar a variante, reinicie o Metro; para rodar ambos simultaneamente use portas Metro distintas e os respectivos builds.

## Fluxos

- Passageiro: cadastro, seleção de partida/destino dentre os locais disponíveis, orçamento, solicitação em dinheiro, acompanhamento do estado, cancelamento antes do início, histórico e avaliação.
- Motorista: cadastro com veículo, aprovação pelo superadmin, disponibilidade, aceite, chegada, início e conclusão; ganhos e histórico.
- A autenticação mobile usa bearer token guardado em `expo-secure-store`. A API decide a autorização de cada usuário.
- Os dados são atualizados consultando a API a cada três segundos enquanto o aplicativo está ativo. Não há garantia de atualização com o app fechado ou em segundo plano.
- A localização do motorista exige permissão explícita e funciona somente em primeiro plano. Não há rastreamento em segundo plano, notificações push, cobrança eletrônica ou navegação curva a curva implementados.
- As distâncias, tempos e tarifas são estimativas para os pontos cadastrados, não resultados de um serviço real de roteamento. A navegação externa usa o aplicativo/serviço aberto pelo sistema.

## Demonstração local

A API só cria contas de exemplo quando é iniciada com `REA_DEMO_MODE=1`. A interface só pode exibir facilidades de demonstração quando a API confirma esse modo e `EXPO_PUBLIC_DEMO_MODE=1` está definido no app. Essas contas e corridas são dados locais de teste; não use esse modo em um serviço público.

```bash
EXPO_PUBLIC_DEMO_MODE=1 EXPO_PUBLIC_API_URL=http://10.0.2.2:3001 npm run start:rider
```

## Exportar e gerar aplicativos

```bash
npm run export:rider
npm run export:driver
APP_VARIANT=rider npx expo config --type public
APP_VARIANT=driver npx expo config --type public
```

A exportação valida a compilação dos bundles JavaScript para Android/iOS. Ela não gera APK/IPA nem comprova funcionamento em um aparelho.

No ambiente de nuvem, mantenha `EXPO_NO_TELEMETRY=1`: o diretório pessoal é protegido e a telemetria do Expo tentaria criar `~/.expo`. Para uma exportação não interativa, use `EXPO_NO_TELEMETRY=1 CI=1 npm run export:rider` e o equivalente `export:driver`. Essa configuração não modifica o diretório pessoal nem desativa verificações de TLS.

O arquivo `eas.json` contém perfis separados para as duas variantes. Antes de usar o EAS, configure os projetos Expo de cada variante, um endereço HTTPS de API em `EXPO_PUBLIC_API_URL`, os identificadores definitivos e suas credenciais de assinatura pelo fluxo seguro do provedor. Não inclua credenciais no repositório.

Perfis disponíveis:

- `preview-rider` e `preview-driver`: distribuição interna; Android em APK. iOS físico depende de assinatura e provisionamento de aparelhos.
- `simulator-rider` e `simulator-driver`: simulador iOS.
- `production-rider` e `production-driver`: builds para publicação, sujeitos às configurações e revisões das lojas.

Nenhum build EAS, envio para loja ou assinatura é executado pela instalação deste projeto. Antes de publicar, valide em Android e iOS reais o login, permissões, retomada de conexão e o ciclo de uma corrida entre os dois aplicativos e o superadmin.

No ambiente de nuvem preparado, a ativação configura diretórios de estado/cache graváveis. Para iniciar sem consultas de rede opcionais, use `npm run start:rider -- --offline --port 8081` e `npm run start:driver -- --offline --port 8082`. Para testes não interativos, acrescente `CI=1`; para recarga automática, omita essa variável. Não combine `--offline` com `--localhost`.
