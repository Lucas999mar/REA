import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, AppState, KeyboardAvoidingView, Linking, Modal, Platform, Pressable, RefreshControl, ScrollView, StatusBar, StyleSheet, Text, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import * as SecureStore from 'expo-secure-store';
import * as Location from 'expo-location';
import { activeStatuses, demoEnabled, money, request, sessionKey, statusLabel, variant } from './src/api';
import { Badge, Body, Button, Card, Field, Label, Route, Title, colors, s } from './src/ui';

const driverApp = variant === 'driver';
const appName = driverApp ? 'Parceiro' : 'Passageiro';
const dateLabel = (date) => new Date(date).toLocaleString('pt-BR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });

export default function App() {
  return <SafeAreaProvider><Application /></SafeAreaProvider>;
}

function Application() {
  const [auth, setAuth] = useState(null);
  const [restoring, setRestoring] = useState(true);
  const [dashboard, setDashboard] = useState(null);
  const [places, setPlaces] = useState([]);
  const [meta, setMeta] = useState({ demoMode: false });
  const [tab, setTab] = useState('home');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [synced, setSynced] = useState(null);
  const [foreground, setForeground] = useState(AppState.currentState === 'active');
  const loading = useRef(null);
  const activeToken = useRef(null);
  const mutation = useRef(false);

  const forgetSession = useCallback(async () => {
    activeToken.current = null;
    loading.current?.abort();
    loading.current = null;
    setAuth(null); setDashboard(null); setTab('home'); setSynced(null);
    try { await SecureStore.deleteItemAsync(sessionKey); }
    catch { setError('Não foi possível remover a sessão do armazenamento seguro. Feche e abra o app para tentar novamente.'); }
  }, []);

  useEffect(() => {
    const subscription = AppState.addEventListener('change', state => setForeground(state === 'active'));
    return () => subscription.remove();
  }, []);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const [metadata, locations] = await Promise.allSettled([request('/meta'), request('/places')]);
        if (mounted) {
          if (metadata.status === 'fulfilled') setMeta(metadata.value);
          if (locations.status === 'fulfilled') setPlaces(locations.value.places);
        }
        const saved = await SecureStore.getItemAsync(sessionKey);
        if (saved) {
          const session = JSON.parse(saved);
          const { user } = await request('/auth/me', { token: session.token });
          if (user.role !== variant) await SecureStore.deleteItemAsync(sessionKey);
          else if (mounted) { activeToken.current = session.token; setAuth({ user, token: session.token }); }
        }
      } catch (cause) {
        if (cause.status === 401) await SecureStore.deleteItemAsync(sessionKey);
        else if (mounted) setError(cause.message);
      } finally { if (mounted) setRestoring(false); }
    })();
    return () => { mounted = false; loading.current?.abort(); activeToken.current = null; };
  }, []);

  const refresh = useCallback(async ({ quiet = false } = {}) => {
    const token = activeToken.current;
    if (!token || loading.current) return;
    const controller = new AbortController();
    loading.current = controller;
    try {
      const data = await request('/dashboard', { token, signal: controller.signal });
      if (activeToken.current !== token || controller.signal.aborted) return;
      setDashboard(data); setAuth(current => current?.token === token ? { ...current, user: data.user } : current); setSynced(new Date());
      setError('');
      if (places.length === 0) {
        const locations = await request('/places', { signal: controller.signal });
        if (activeToken.current === token && !controller.signal.aborted) setPlaces(locations.places);
      }
    } catch (cause) {
      if (cause.name === 'AbortError' || activeToken.current !== token) return;
      if (cause.status === 401) { await forgetSession(); setError('Sua sessão expirou. Entre novamente.'); }
      else setError(cause.message);
    } finally { if (loading.current === controller) loading.current = null; }
  }, [auth?.token, forgetSession, places.length]);

  useEffect(() => {
    if (!auth || !foreground) return;
    refresh({ quiet: true });
    const timer = setInterval(() => refresh({ quiet: true }), 3000);
    return () => { clearInterval(timer); loading.current?.abort(); loading.current = null; };
  }, [auth?.token, foreground, refresh]);

  const authenticate = async (path, form) => {
    setBusy(true); setError('');
    try {
      const session = await request(path, { method: 'POST', body: form });
      if (session.user.role !== variant) {
        await request('/auth/logout', { method: 'POST', token: session.token }).catch(() => {});
        throw new Error(`Esta conta não pertence ao aplicativo ${appName.toLowerCase()}. Use o aplicativo correspondente.`);
      }
      if (!session.token) throw new Error('O servidor não retornou uma sessão para o aplicativo.');
      await SecureStore.setItemAsync(sessionKey, JSON.stringify({ token: session.token }));
      activeToken.current = session.token;
      setDashboard(null); setSynced(null);
      setAuth(session); setTab('home');
      request('/meta').then(setMeta).catch(() => {});
    } catch (cause) { setError(cause.message); }
    finally { setBusy(false); }
  };

  const action = async (path, body, { success } = {}) => {
    const token = activeToken.current;
    if (mutation.current || !token) return null;
    mutation.current = true;
    setBusy(true); setError('');
    try {
      const result = await request(path, { method: 'POST', body, token });
      if (activeToken.current !== token) return null;
      loading.current?.abort(); loading.current = null;
      await refresh();
      if (activeToken.current !== token) return null;
      if (success) Alert.alert('Tudo certo', success);
      return result;
    } catch (cause) {
      if (activeToken.current === token) {
        if (cause.status === 401) await forgetSession();
        setError(cause.message);
      }
      return null;
    }
    finally { mutation.current = false; setBusy(false); }
  };

  const logout = () => Alert.alert('Sair da sua conta?', 'Você poderá entrar novamente quando quiser.', [
    { text: 'Ficar', style: 'cancel' },
    { text: 'Sair', style: 'destructive', onPress: async () => {
      const token = activeToken.current;
      await forgetSession();
      try { await request('/auth/logout', { method: 'POST', token }); }
      catch { setError('A conta foi removida deste aparelho. Não foi possível revogar a sessão no servidor.'); }
    } },
  ]);

  return <SafeAreaView style={s.screen} edges={['top', 'bottom']}>
    <StatusBar barStyle="dark-content" backgroundColor={colors.cream} />
    {restoring ? <View style={styles.center}><Brand/><ActivityIndicator color={colors.teal}/><Body>Preparando seu caminho…</Body></View> : <>
      <View style={styles.topBar}><Brand/><Badge tone={driverApp ? 'gold' : 'green'}>{appName.toUpperCase()}</Badge></View>
      {error ? <Pressable accessibilityRole="button" accessibilityLabel="Dispensar aviso" onPress={() => setError('')} style={styles.error}><Text style={styles.errorText}>{error}</Text><Text style={styles.errorClose}>×</Text></Pressable> : null}
      {!auth ? <Login busy={busy} onSubmit={authenticate} demoMode={demoEnabled && meta.demoMode} /> : <>
        <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={s.content} refreshControl={<RefreshControl refreshing={false} onRefresh={() => refresh()} tintColor={colors.teal}/>}>
          <View style={s.row}><View><Label>QUE BOM TER VOCÊ AQUI</Label><Title>Olá, {auth.user.name.split(' ')[0]}.</Title></View><View style={styles.avatar}><Text style={styles.avatarText}>{auth.user.name.slice(0, 1).toUpperCase()}</Text></View></View>
          {meta.demoMode && <View style={styles.demoNotice}><Body style={{ color: '#8F651B' }}>Ambiente de demonstração · corridas de teste</Body></View>}
          {!dashboard ? <Card><ActivityIndicator color={colors.teal}/><Body>Carregando sua conta…</Body><Button secondary title="Tentar novamente" onPress={() => refresh()}/></Card> : <>
            {tab === 'home' && (driverApp
              ? <DriverHome dashboard={dashboard} action={action} busy={busy}/>
              : <RiderHome dashboard={dashboard} places={places} token={auth.token} action={action} busy={busy} onError={setError}/>)}
            {tab === 'trips' && <TripHistory rides={dashboard.rides} action={action} busy={busy}/>}
            {tab === 'account' && <Account user={dashboard.user} onLogout={logout}/>}
          </>}
          <Body style={styles.sync}>{synced ? `Atualizado às ${synced.toLocaleTimeString('pt-BR')}` : 'Aguardando sincronização'} · dados compartilhados com a central</Body>
        </ScrollView>
        <View style={styles.tabs}>{[
          ['home', driverApp ? '◉' : '⌂', driverApp ? 'Trabalhar' : 'Viajar'], ['trips', '≡', 'Corridas'], ['account', '○', 'Minha conta'],
        ].map(([key, icon, title]) => <Pressable accessibilityRole="tab" accessibilityState={{ selected: tab === key }} accessibilityLabel={title} key={key} onPress={() => setTab(key)} style={[styles.tab, tab === key && styles.selectedTab]}><Text style={[styles.tabIcon, tab === key && { color: colors.teal }]}>{icon}</Text><Text style={[styles.tabText, tab === key && { color: colors.teal }]}>{title}</Text></Pressable>)}</View>
      </>}
    </>}
  </SafeAreaView>;
}

function Brand() { return <View style={styles.brand}><View style={styles.brandIcon}><Text style={styles.brandArrow}>↗</Text></View><Text style={styles.brandText}>rea<Text style={{ color: colors.gold }}>.</Text></Text></View>; }

function Login({ busy, onSubmit, demoMode }) {
  const [register, setRegister] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '', model: '', plate: '', color: '' });
  const change = (key) => value => setForm(current => ({ ...current, [key]: value }));
  const submit = () => onSubmit(register ? '/auth/register' : '/auth/login', register ? {
    name: form.name.trim(), email: form.email.trim(), password: form.password, phone: form.phone.trim(), role: variant,
    ...(driverApp ? { vehicle: { model: form.model.trim(), plate: form.plate.trim().toUpperCase(), color: form.color.trim() } } : {}),
  } : { email: form.email.trim(), password: form.password });
  const valid = form.email.includes('@') && form.password.length >= (register ? 12 : 1) && form.password.length <= 128 && (!register || (form.name.trim().length >= 2 && form.phone.trim().length >= 8 && (!driverApp || (form.model && form.plate && form.color))));
  return <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={s.content}>
      <View style={styles.loginHero}><Label style={{ color: '#BBD6C9' }}>MOBILIDADE QUE CONECTA</Label><Title style={styles.heroTitle}>{driverApp ? 'Seu volante.\nNovas possibilidades.' : 'Seu próximo destino\ncomeça aqui.'}</Title><Body style={{ color: '#C4DCD0', marginTop: 8 }}>{driverApp ? 'Receba solicitações, faça corridas e acompanhe seus ganhos em um só lugar.' : 'Um jeito simples de ir, chegar e aproveitar o caminho.'}</Body><View style={styles.heroRoute}><View style={styles.heroDot}/><View style={styles.heroLine}/><Text style={{ color: '#EACB7F', fontSize: 30 }}>↗</Text></View></View>
      <Card>
        <View><Text style={s.sectionTitle}>{register ? 'Vamos criar sua conta' : 'Bem-vindo de volta'}</Text><Body style={{ marginTop: 6 }}>{register ? 'Preencha seus dados para começar.' : 'Entre para continuar seu caminho.'}</Body></View>
        {register && <Field label="Seu nome" placeholder="Como podemos chamar você?" value={form.name} onChangeText={change('name')} autoComplete="name"/>}
        <Field label="E-mail" placeholder="voce@exemplo.com" value={form.email} onChangeText={change('email')} keyboardType="email-address" autoCapitalize="none" autoComplete="email"/>
        <Field label="Senha" placeholder={register ? 'De 12 a 128 caracteres' : 'Sua senha'} value={form.password} onChangeText={change('password')} secureTextEntry autoComplete={register ? 'new-password' : 'current-password'} maxLength={128}/>
        {register && <Field label="Celular com DDD" placeholder="11999999999" value={form.phone} onChangeText={change('phone')} keyboardType="phone-pad" autoComplete="tel"/>}
        {register && driverApp && <><View style={s.divider}/><Label>SEU VEÍCULO</Label><Field label="Marca e modelo" placeholder="Ex.: Chevrolet Onix" value={form.model} onChangeText={change('model')}/><Field label="Placa" placeholder="ABC1D23" autoCapitalize="characters" value={form.plate} onChangeText={change('plate')}/><Field label="Cor" placeholder="Ex.: Prata" value={form.color} onChangeText={change('color')}/><Body>Seu cadastro será avaliado pela central antes de você receber corridas.</Body></>}
        <Button title={register ? 'Criar minha conta' : 'Entrar'} onPress={submit} disabled={!valid} loading={busy}/>
        <Pressable accessibilityRole="button" onPress={() => setRegister(!register)} style={styles.textButton}><Text style={styles.link}>{register ? 'Já tenho uma conta. Entrar' : 'Primeira vez aqui? Criar conta'}</Text></Pressable>
      </Card>
      {demoMode && <Button secondary title={`Experimentar como ${appName.toLowerCase()}`} disabled={busy} onPress={() => onSubmit('/auth/login', { email: driverApp ? 'motorista@rea.local' : 'passageiro@rea.local', password: 'ReaDemo!2026' })}/>}
      <Body style={{ textAlign: 'center' }}>REA Mobilidade · {appName}</Body>
    </ScrollView>
  </KeyboardAvoidingView>;
}

function RiderHome({ dashboard, places, token, action, busy, onError }) {
  const activeRide = dashboard.rides.find(ride => activeStatuses.includes(ride.status));
  const unrated = dashboard.rides.find(ride => ride.status === 'completed' && !ride.rating);
  const [originId, setOriginId] = useState('');
  const [destinationId, setDestinationId] = useState('');
  const [category, setCategory] = useState('economy');
  const [selection, setSelection] = useState(null);
  const [quote, setQuote] = useState(null);
  const [quoting, setQuoting] = useState(false);
  const quoteRequest = useRef(null);
  const selectionKey = `${originId}:${destinationId}:${category}`;
  const currentSelection = useRef(selectionKey);
  currentSelection.current = selectionKey;
  const origin = places.find(place => place.id === originId);
  const destination = places.find(place => place.id === destinationId);
  useEffect(() => { if (!originId && places.length) setOriginId(places[0].id); if (!destinationId && places.length > 1) setDestinationId(places[1].id); }, [places, originId, destinationId]);
  useEffect(() => {
    setQuote(null); setQuoting(false);
    return () => { quoteRequest.current?.abort(); quoteRequest.current = null; };
  }, [selectionKey, token]);
  const estimate = async () => {
    quoteRequest.current?.abort();
    const controller = new AbortController();
    const selected = selectionKey;
    quoteRequest.current = controller;
    setQuoting(true);
    try {
      const result = await request('/quotes', { method: 'POST', body: { originId, destinationId, category }, token, signal: controller.signal });
      if (!controller.signal.aborted && currentSelection.current === selected) setQuote(result.quote);
    }
    catch (cause) { if (cause.name !== 'AbortError' && currentSelection.current === selected) onError(cause.message); }
    finally { if (quoteRequest.current === controller) { quoteRequest.current = null; setQuoting(false); } }
  };
  if (activeRide) return <ActiveRide ride={activeRide} action={action} busy={busy}/>;
  return <>
    <View><Title style={{ fontSize: 29 }}>Para onde vamos?</Title><Body style={{ marginTop: 7 }}>Escolha seu caminho. A gente conecta você.</Body></View>
    <Card>
      <Pressable accessibilityRole="button" accessibilityLabel="Selecionar local de embarque" style={s.routeRow} onPress={() => setSelection('origin')}><View style={s.originDot}/><View style={{ flex: 1 }}><Label>SEU PONTO DE PARTIDA</Label><Text style={s.placeName}>{origin?.name || 'Selecione o embarque'}</Text><Body>{origin?.address}</Body></View><Text style={styles.chevron}>›</Text></Pressable>
      <View style={s.divider}/>
      <Pressable accessibilityRole="button" accessibilityLabel="Selecionar destino" style={s.routeRow} onPress={() => setSelection('destination')}><View style={s.destinationDot}/><View style={{ flex: 1 }}><Label>QUERO IR PARA</Label><Text style={s.placeName}>{destination?.name || 'Selecione o destino'}</Text><Body>{destination?.address}</Body></View><Text style={styles.chevron}>›</Text></Pressable>
    </Card>
    <View style={s.row}>{[['economy', 'REA Essencial', 'Simples e econômico', '↗'], ['comfort', 'REA Conforto', 'Mais conforto no caminho', '✧']].map(([key, title, text, icon]) => <Pressable accessibilityRole="radio" accessibilityState={{ checked: category === key }} key={key} onPress={() => setCategory(key)} style={[styles.category, category === key && styles.categorySelected]}><Text style={styles.categoryIcon}>{icon}</Text><Text style={styles.categoryTitle}>{title}</Text><Body style={{ fontSize: 11 }}>{text}</Body><View style={[styles.radio, category === key && { backgroundColor: colors.teal }]}/></Pressable>)}</View>
    {quote ? <Card><View style={s.row}><View><Label>VALOR ESTIMADO</Label><Text style={s.metric}>{money(quote.totalCents)}</Text></View><Badge>{quote.distanceKm.toFixed(1)} km · {quote.durationMinutes} min</Badge></View><Body>Pagamento em dinheiro ao motorista. Distância e duração são estimativas; este piloto usa pontos predefinidos em São Paulo.</Body><Button title="Solicitar corrida" disabled={busy} loading={busy} onPress={async () => { const result = await action('/rides', { originId, destinationId, category, paymentMethod: 'cash' }); if (result) setQuote(null); }}/></Card> : <><Button title="Ver estimativa da corrida" disabled={!origin || !destination || originId === destinationId || busy} loading={quoting} onPress={estimate}/><Body style={{ textAlign: 'center' }}>Pontos disponíveis em São Paulo · pagamento em dinheiro</Body></>}
    {unrated && <RatingCard ride={unrated} action={action} busy={busy}/>}
    <PlacePicker visible={Boolean(selection)} places={places} title={selection === 'origin' ? 'Onde você está?' : 'Qual é seu destino?'} onClose={() => setSelection(null)} onSelect={place => { selection === 'origin' ? setOriginId(place.id) : setDestinationId(place.id); setSelection(null); }}/>
  </>;
}

function PlacePicker({ visible, places, title, onClose, onSelect }) {
  const [query, setQuery] = useState('');
  const filtered = places.filter(place => `${place.name} ${place.address}`.toLocaleLowerCase('pt-BR').includes(query.toLocaleLowerCase('pt-BR')));
  return <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}><SafeAreaView style={s.screen}><View style={s.content}><View style={s.row}><Title>{title}</Title><Pressable accessibilityRole="button" accessibilityLabel="Fechar locais" style={styles.closeButton} onPress={onClose}><Text style={{ fontSize: 25, color: colors.teal }}>×</Text></Pressable></View><Field label="Buscar entre os pontos disponíveis" placeholder="Nome do lugar ou endereço" value={query} onChangeText={setQuery}/></View><ScrollView contentContainerStyle={{ paddingHorizontal: 24, paddingBottom: 30 }}>{filtered.map(place => <Pressable accessibilityRole="button" key={place.id} style={styles.placeOption} onPress={() => { onSelect(place); setQuery(''); }}><Text style={s.placeName}>{place.name}</Text><Body>{place.address}</Body></Pressable>)}{!filtered.length && <Body>Nenhum ponto encontrado. Tente outro nome.</Body>}</ScrollView></SafeAreaView></Modal>;
}

function ActiveRide({ ride, action, busy }) {
  const canCancel = ['requested', 'accepted', 'arrived'].includes(ride.status);
  const next = { accepted: ['arrived', 'Cheguei ao embarque'], arrived: ['in_progress', 'Iniciar corrida'], in_progress: ['completed', 'Concluir corrida'] }[ride.status];
  const step = ['requested', 'accepted', 'arrived', 'in_progress'].indexOf(ride.status);
  const navigate = async () => {
    const place = ride.status === 'in_progress' ? ride.destination : ride.origin;
    try { await Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${place.lat},${place.lng}`); }
    catch { Alert.alert('Navegação indisponível', 'Não foi possível abrir o aplicativo de mapas.'); }
  };
  return <>
    <Card style={{ backgroundColor: colors.teal, borderColor: colors.teal }}><Label style={{ color: '#A8CCBA' }}>SUA CORRIDA ESTÁ EM ANDAMENTO</Label><Title style={{ color: 'white' }}>{statusLabel[ride.status]}</Title><Body style={{ color: '#C4DCD0' }}>{ride.status === 'requested' ? 'Sua solicitação está disponível para nossos parceiros. Você verá a confirmação por aqui.' : driverApp ? 'Atualize cada etapa para manter passageiro e central informados.' : 'As etapas da sua viagem são atualizadas pelo motorista.'}</Body><View style={styles.progress}>{[0, 1, 2, 3].map(index => <View key={index} style={[styles.progressBar, { backgroundColor: index <= step ? '#DAB773' : '#3A7566' }]}/>)}</View></Card>
    <Card><Route origin={ride.origin} destination={ride.destination}/><View style={s.divider}/><View style={s.row}><Body>{ride.category === 'comfort' ? 'REA Conforto' : 'REA Essencial'} · dinheiro</Body><Text style={styles.price}>{money(ride.totalCents)}</Text></View></Card>
    <Card><View style={s.row}><View style={styles.avatar}><Text style={styles.avatarText}>{(driverApp ? ride.riderName : ride.driverName || '?').slice(0, 1)}</Text></View><View style={{ flex: 1 }}><Label>{driverApp ? 'SEU PASSAGEIRO' : 'MOTORISTA PARCEIRO'}</Label><Text style={s.placeName}>{driverApp ? ride.riderName : ride.driverName || 'Aguardando aceite'}</Text>{ride.driverVehicle && !driverApp && <Body>{ride.driverVehicle.model} · {ride.driverVehicle.color}{'\n'}{ride.driverVehicle.plate}</Body>}</View></View>{ride.driverLocation && !driverApp && <Body>Última posição informada: {ride.driverLocation.lat.toFixed(5)}, {ride.driverLocation.lng.toFixed(5)}</Body>}</Card>
    {driverApp && <><Button secondary title="Abrir navegação" onPress={navigate}/>{next && <Button title={next[1]} loading={busy} onPress={() => {
      if (next[0] === 'completed') Alert.alert('Concluir esta corrida?', `Confirme a chegada e o recebimento de ${money(ride.totalCents)} em dinheiro.`, [{ text: 'Voltar', style: 'cancel' }, { text: 'Concluir', onPress: () => action(`/rides/${ride.id}/status`, { status: next[0] }) }]);
      else action(`/rides/${ride.id}/status`, { status: next[0] });
    }}/>}</>}
    {canCancel && <Button danger title="Cancelar corrida" disabled={busy} onPress={() => Alert.alert('Cancelar esta corrida?', 'O passageiro, o motorista e a central receberão a atualização.', [{ text: 'Manter corrida', style: 'cancel' }, { text: 'Cancelar corrida', style: 'destructive', onPress: () => action(`/rides/${ride.id}/status`, { status: 'cancelled' }) }])}/>}
    <Body style={{ textAlign: 'center' }}>Corrida #{ride.id.slice(0, 8)}</Body>
  </>;
}

function DriverHome({ dashboard, action, busy }) {
  const user = dashboard.user;
  const activeRide = dashboard.rides.find(ride => activeStatuses.includes(ride.status));
  const [locationBusy, setLocationBusy] = useState(false);
  const [sharing, setSharing] = useState(false);
  const [locationError, setLocationError] = useState('');
  const watcher = useRef(null);
  const mounted = useRef(false);
  const locationGeneration = useRef(0);
  const online = useRef(user.online);
  online.current = user.online;
  const currentAction = useRef(action);
  currentAction.current = action;
  const stopSharing = () => {
    locationGeneration.current += 1;
    watcher.current?.remove(); watcher.current = null;
    if (mounted.current) { setSharing(false); setLocationBusy(false); }
  };
  useEffect(() => {
    mounted.current = true;
    const subscription = AppState.addEventListener('change', state => { if (state !== 'active') stopSharing(); });
    return () => { mounted.current = false; subscription.remove(); stopSharing(); };
  }, []);
  useEffect(() => { if (!user.online) stopSharing(); }, [user.online]);
  const share = async () => {
    if (sharing) { stopSharing(); return; }
    const generation = ++locationGeneration.current;
    const stillCurrent = () => mounted.current && online.current && AppState.currentState === 'active' && generation === locationGeneration.current;
    setLocationBusy(true); setLocationError('');
    try {
      const permission = await Location.requestForegroundPermissionsAsync();
      if (!stillCurrent()) return;
      if (permission.status !== 'granted') { setLocationError('Permita a localização nas configurações do aparelho para compartilhar sua posição.'); return; }
      const subscription = await Location.watchPositionAsync({ accuracy: Location.Accuracy.Balanced, timeInterval: 10000, distanceInterval: 25 }, position => {
        if (stillCurrent()) currentAction.current('/driver/location', { lat: position.coords.latitude, lng: position.coords.longitude });
      });
      if (!stillCurrent()) { subscription.remove(); return; }
      watcher.current = subscription;
      setSharing(true);
    } catch { if (stillCurrent()) setLocationError('Não foi possível obter sua localização. Confira se o GPS está ligado.'); }
    finally { if (mounted.current && generation === locationGeneration.current) setLocationBusy(false); }
  };
  if (!user.approved) return <Card><Badge tone="gold">CADASTRO EM ANÁLISE</Badge><Title>Quase tudo pronto.</Title><Body>A central está avaliando seu cadastro e veículo. Assim que for aprovado, você poderá ficar online e receber solicitações por aqui.</Body><View style={s.divider}/><Body>{user.vehicle?.model} · {user.vehicle?.plate}</Body></Card>;
  return <>
    <Card style={{ backgroundColor: colors.teal, borderColor: colors.teal }}><View style={s.row}><View><Label style={{ color: '#A8CCBA' }}>SEU STATUS</Label><Title style={{ color: 'white' }}>{user.online ? 'Você está online' : 'Vamos começar?'}</Title></View><View style={[styles.onlineDot, { backgroundColor: user.online ? '#BFE2A4' : '#759C89' }]}/></View><Body style={{ color: '#C4DCD0' }}>{user.online ? 'Você está disponível para receber novas corridas.' : 'Fique online quando estiver pronto para receber passageiros.'}</Body><Button secondary title={user.online ? 'Ficar offline' : 'Ficar online'} disabled={busy || Boolean(activeRide)} loading={busy} onPress={() => action('/driver/availability', { online: !user.online })}/>{activeRide && <Body style={{ color: '#C4DCD0' }}>Conclua a corrida atual antes de ficar offline.</Body>}</Card>
    {activeRide ? <ActiveRide ride={activeRide} action={action} busy={busy}/> : <>
      <View style={s.row}><Card style={{ flex: 1, padding: 16 }}><Label>SEUS GANHOS</Label><Text style={[s.metric, { fontSize: 24 }]}>{money(dashboard.stats.driverEarningsCents)}</Text><Body style={{ fontSize: 10 }}>Líquido após comissão</Body></Card><Card style={{ flex: 1, padding: 16 }}><Label>CONCLUÍDAS</Label><Text style={[s.metric, { fontSize: 24 }]}>{dashboard.stats.completedRides}</Text><Body style={{ fontSize: 10 }}>Todas as suas corridas</Body></Card></View>
      <View style={s.row}><Text style={s.sectionTitle}>Solicitações disponíveis</Text><Badge>{dashboard.availableRides.length}</Badge></View>
      {dashboard.availableRides.length ? dashboard.availableRides.map(ride => <Card key={ride.id}><View style={s.row}><Badge>{ride.category === 'comfort' ? 'CONFORTO' : 'ESSENCIAL'}</Badge><Text style={styles.price}>{money(ride.totalCents - ride.commissionCents)}</Text></View><Route origin={ride.origin} destination={ride.destination} compact/><View style={s.row}><Body>{ride.distanceKm.toFixed(1)} km · estimativa {ride.durationMinutes} min</Body><Body>Dinheiro</Body></View><Button title="Aceitar corrida" loading={busy} onPress={() => action(`/rides/${ride.id}/accept`, {})}/></Card>) : <Card><Text style={styles.emptyIcon}>↗</Text><Text style={s.sectionTitle}>{user.online ? 'Pronto para a próxima' : 'Seu próximo caminho espera'}</Text><Body>{user.online ? 'Novas solicitações aparecem aqui automaticamente. Mantenha o aplicativo aberto.' : 'Fique online para ver as corridas disponíveis.'}</Body></Card>}
    </>}
    {user.online && <Card><View style={s.row}><Text style={s.sectionTitle}>Sua localização</Text><Badge tone={sharing ? 'green' : 'gray'}>{sharing ? 'ATIVA' : 'PAUSADA'}</Badge></View><Body>Compartilhe sua posição com a central e o passageiro da sua corrida, somente enquanto esta tela está aberta. Ao sair do app, o compartilhamento para.</Body>{locationError ? <Body style={{ color: colors.red }}>{locationError}</Body> : null}<Button secondary title={sharing ? 'Parar de compartilhar' : 'Ativar localização'} loading={locationBusy} onPress={share}/></Card>}
  </>;
}

function RatingCard({ ride, action, busy }) {
  return <Card><Label>SUA OPINIÃO IMPORTA</Label><Text style={s.sectionTitle}>Como foi sua última corrida?</Text><Body>{ride.driverName || 'Motorista parceiro'} · {ride.destination.name}</Body><View style={s.row}>{[1, 2, 3, 4, 5].map(rating => <Pressable key={rating} accessibilityRole="button" accessibilityLabel={`Avaliar com ${rating} estrelas`} disabled={busy} onPress={() => action(`/rides/${ride.id}/rating`, { rating }, { success: 'Obrigado pela sua avaliação!' })} style={styles.star}><Text style={{ color: colors.gold, fontSize: 31 }}>★</Text><Text style={{ fontSize: 10, color: colors.muted }}>{rating}</Text></Pressable>)}</View></Card>;
}
function TripHistory({ rides, action, busy }) {
  return <><View><Title>Seus caminhos</Title><Body style={{ marginTop: 7 }}>Cada viagem, tudo em um só lugar.</Body></View>{rides.length ? rides.map(ride => <Card key={ride.id}><View style={s.row}><Badge tone={ride.status === 'cancelled' ? 'gray' : 'green'}>{statusLabel[ride.status]}</Badge><Text style={styles.price}>{money(driverApp && ride.status === 'completed' ? ride.totalCents - ride.commissionCents : ride.totalCents)}</Text></View><Body>{dateLabel(ride.createdAt)}</Body><Route origin={ride.origin} destination={ride.destination} compact/>{ride.rating && <Body>{'★'.repeat(ride.rating)} · avaliação da corrida</Body>}{!driverApp && ride.status === 'completed' && !ride.rating && <RatingCard ride={ride} action={action} busy={busy}/>}</Card>) : <Card><Text style={styles.emptyIcon}>↗</Text><Text style={s.sectionTitle}>O primeiro caminho vem aí</Text><Body>Suas corridas aparecerão aqui quando você começar.</Body></Card>}</>;
}
function Account({ user, onLogout }) {
  return <><Title>Minha conta</Title><Card><Label>SEUS DADOS</Label><Text style={s.sectionTitle}>{user.name}</Text><Body>{user.email}{'\n'}{user.phone}</Body><Badge>{driverApp ? 'MOTORISTA PARCEIRO' : 'PASSAGEIRO'}</Badge>{user.vehicle && <><View style={s.divider}/><Label>SEU VEÍCULO</Label><Text style={s.placeName}>{user.vehicle.model}</Text><Body>{user.vehicle.color} · {user.vehicle.plate}</Body><Badge tone={user.approved ? 'green' : 'gold'}>{user.approved ? 'CADASTRO APROVADO' : 'EM ANÁLISE'}</Badge></>}</Card><Card><Text style={s.sectionTitle}>Um caminho transparente</Text><Body>Este piloto aceita pagamento em dinheiro e usa locais predefinidos em São Paulo. As estimativas não incluem trânsito em tempo real.</Body><Body>As atualizações de corrida são consultadas enquanto o aplicativo está aberto. Não há notificações em segundo plano nesta versão.</Body></Card><Button secondary title="Sair da conta" onPress={onLogout}/></>;
}

const styles = StyleSheet.create({
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 25 },
  topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 24, paddingVertical: 15, borderBottomWidth: 1, borderBottomColor: colors.border },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  brandIcon: { width: 29, height: 29, borderRadius: 9, backgroundColor: colors.teal, alignItems: 'center', justifyContent: 'center' },
  brandArrow: { color: '#ECD18E', fontSize: 21, fontWeight: '700', lineHeight: 25 },
  brandText: { color: colors.ink, fontSize: 31, fontWeight: '800', letterSpacing: -2 },
  avatar: { height: 47, width: 47, backgroundColor: '#E3E9DC', borderRadius: 24, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: colors.teal, fontSize: 19, fontWeight: '600' },
  error: { backgroundColor: '#FAEAE4', marginHorizontal: 16, marginTop: 10, padding: 14, borderRadius: 12, flexDirection: 'row', gap: 12 },
  errorText: { color: colors.red, fontSize: 13, lineHeight: 19, flex: 1 },
  errorClose: { color: colors.red, fontSize: 20 },
  loginHero: { backgroundColor: colors.teal, padding: 26, paddingBottom: 12, borderRadius: 26, overflow: 'hidden' },
  heroTitle: { color: '#FBFAED', fontSize: 32, lineHeight: 39, marginTop: 9 },
  heroRoute: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 20, marginBottom: 5 },
  heroDot: { width: 12, height: 12, borderRadius: 6, borderWidth: 3, borderColor: '#D4BD7E' },
  heroLine: { height: 2, backgroundColor: '#548575', flex: 1 },
  textButton: { minHeight: 42, alignItems: 'center', justifyContent: 'center' },
  link: { fontSize: 13, color: colors.teal, fontWeight: '600' },
  tabs: { flexDirection: 'row', paddingTop: 9, paddingHorizontal: 18, paddingBottom: 8, gap: 8, borderTopWidth: 1, borderTopColor: colors.border, backgroundColor: '#FEFEFA' },
  tab: { flex: 1, minHeight: 55, alignItems: 'center', justifyContent: 'center', borderRadius: 14, gap: 2 },
  selectedTab: { backgroundColor: colors.mint },
  tabIcon: { fontSize: 24, color: colors.muted, lineHeight: 27 },
  tabText: { fontSize: 10, fontWeight: '600', color: colors.muted },
  demoNotice: { paddingHorizontal: 12, paddingVertical: 9, borderRadius: 10, backgroundColor: '#FFF2D7' },
  sync: { fontSize: 10, textAlign: 'center', lineHeight: 15, marginTop: 5 },
  chevron: { fontSize: 25, color: '#9AAA9E' },
  category: { flex: 1, padding: 16, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, borderRadius: 20, minHeight: 155, gap: 7 },
  categorySelected: { borderColor: colors.teal, backgroundColor: '#EDF4ED' },
  categoryIcon: { fontSize: 30, color: colors.teal },
  categoryTitle: { fontWeight: '700', color: colors.ink, fontSize: 14 },
  radio: { position: 'absolute', right: 14, top: 18, width: 14, height: 14, borderRadius: 7, borderWidth: 2, borderColor: '#759381' },
  closeButton: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center', borderRadius: 22, backgroundColor: colors.mint },
  placeOption: { paddingVertical: 20, borderBottomWidth: 1, borderBottomColor: colors.border, gap: 5 },
  progress: { flexDirection: 'row', gap: 8, marginTop: 6 },
  progressBar: { flex: 1, height: 4, borderRadius: 2 },
  price: { fontSize: 19, color: colors.ink, fontWeight: '700' },
  onlineDot: { width: 13, height: 13, borderRadius: 7, borderWidth: 3, borderColor: '#79A18C' },
  emptyIcon: { fontSize: 38, color: '#B7C7B9', marginBottom: 3 },
  star: { flex: 1, minHeight: 55, alignItems: 'center', justifyContent: 'center' },
});
