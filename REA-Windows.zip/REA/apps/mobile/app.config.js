const variant = process.env.APP_VARIANT || 'rider';
if (!['rider', 'driver'].includes(variant)) {
  throw new Error('APP_VARIANT deve ser rider ou driver.');
}
const driver = variant === 'driver';
const apiUrl = (process.env.EXPO_PUBLIC_API_URL || 'http://127.0.0.1:3001').replace(/\/+$/, '');
const parsedApiUrl = new URL(apiUrl);
if (!['http:', 'https:'].includes(parsedApiUrl.protocol)) {
  throw new Error('EXPO_PUBLIC_API_URL deve usar HTTP ou HTTPS.');
}
if (process.env.EAS_BUILD_PROFILE?.startsWith('production') &&
    (parsedApiUrl.protocol !== 'https:' || ['localhost', '127.0.0.1', '[::1]'].includes(parsedApiUrl.hostname))) {
  throw new Error('Configure EXPO_PUBLIC_API_URL com a API HTTPS publicada antes do build de produção.');
}

module.exports = {
  expo: {
    name: driver ? 'REA Motorista' : 'REA Passageiro',
    slug: driver ? 'rea-motorista' : 'rea-passageiro',
    scheme: driver ? 'rea-motorista' : 'rea-passageiro',
    version: '1.0.0',
    orientation: 'portrait',
    userInterfaceStyle: 'light',
    backgroundColor: '#F6F5F0',
    platforms: ['ios', 'android'],
    ios: {
      supportsTablet: true,
      bundleIdentifier: driver ? 'com.reamobilidade.motorista' : 'com.reamobilidade.passageiro',
      infoPlist: {
        NSLocalNetworkUsageDescription: 'Conectar ao servidor REA da sua rede durante o desenvolvimento.',
        ITSAppUsesNonExemptEncryption: false,
      },
    },
    android: {
      package: driver ? 'com.reamobilidade.motorista' : 'com.reamobilidade.passageiro',
      blockedPermissions: [
        'android.permission.ACCESS_BACKGROUND_LOCATION',
        'android.permission.FOREGROUND_SERVICE_LOCATION',
        ...(!driver ? ['android.permission.ACCESS_COARSE_LOCATION', 'android.permission.ACCESS_FINE_LOCATION'] : []),
      ],
    },
    plugins: [
      ['expo-secure-store', { configureAndroidBackup: true, faceIDPermission: false }],
      ['expo-location', {
        locationWhenInUsePermission: driver
          ? 'Permitir que a REA compartilhe sua localização durante a corrida enquanto o app estiver aberto.'
          : false,
        locationAlwaysAndWhenInUsePermission: false,
        locationAlwaysPermission: false,
        motionUsagePermission: false,
        locationFullAccuracyPermission: false,
        isIosBackgroundLocationEnabled: false,
        isAndroidBackgroundLocationEnabled: false,
        isAndroidForegroundServiceEnabled: false,
      }],
    ],
    extra: { variant, apiUrl },
  },
};
