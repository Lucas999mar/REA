# Validação executada

Este relatório separa validação na máquina atual, configuração reutilizável e etapas ainda não executadas. Ele não comprova publicação nem funcionamento em aparelhos reais.

| Componente | Resultado observado |
| --- | --- |
| API de mobilidade — `npm test` | **11 testes aprovados**, sem falhas ou skips. |
| Painel superadmin — `npm run build` | Compilação de produção aprovada, 1.579 módulos processados. |
| Painel — Chromium/Playwright | Login, dashboard, edição/persistência/restauração de tarifas, tela de motoristas, detalhes da corrida e Escape, layout de 390px sem transbordamento horizontal, logout e revogação da sessão aprovados. Nenhum erro JavaScript de execução observado. |
| Passageiro — `npm run export:rider` | Bundles Android e iOS gerados, não vazios. |
| Motorista — `npm run export:driver` | Bundles Android e iOS gerados, não vazios. |
| Metro das duas variantes | Processos iniciados nas portas 8081/8082; `/status` e manifestos Android/iOS válidos. Variantes e identificadores distintos confirmados. |
| Instalação reutilizável | Script completo reexecutado com lockfiles, build do toolkit, build do painel e instalação móvel; saída 0. Ativação adicional de diretórios graváveis do Expo/cache validada pela inicialização e leitura dos manifestos. |
| REA 6.7.0 — build e análise JavaScript | `npm run build:cached`, versão e análise do exemplo Notes/Electron aprovados. |
| REA — navegador local | Descoberta de alvos CDP e inspeção da página Notes local aprovadas. |
| REA — testes focados existentes | **5 aprovados e 1 reprovado** em 6 testes executados. Falha upstream diagnosticada abaixo. |
| Machine — páginas públicas | Homepage e quatro páginas de produto consultadas via HTTPS, sem login; comparação em [REFERENCIA-MACHINE.md](REFERENCIA-MACHINE.md). |
| REA — HTML público da Machine | Análise estática do HTML obtido via curl concluída; quatro nós no grafo, cobertura incompleta explicitamente informada pelo REA. |

## Cobertura dos testes da API

Os testes exercitam o mesmo ciclo de corrida visto separadamente por passageiro, motorista e superadmin; isolamento de leitura/alteração; aprovação e disponibilidade; aceite concorrente com um único vencedor; transições inválidas; cálculo de tarifa no servidor; avaliação; sessões web HttpOnly e mobile por token; persistência e revogação; tarifas novas sem alterar corridas existentes; localização e privacidade do histórico; eventos SSE; bootstrap do administrador; separação entre bancos demo e normais; encerramento com SSE aberto e inicialização com porta ocupada.

A verificação do painel encontrou e corrigiu uma incompatibilidade entre o multiplicador padrão `1.35` e o passo do campo numérico, que impedia salvar o formulário. Também corrigiu o posicionamento de um cabeçalho acessível da tabela que provocava transbordamento da página em telas estreitas. O teste no navegador foi repetido após as correções e passou.

## Falha conhecida no REA externo

Comando executado em `/workspace/rea-toolkit`:

```bash
npm run test:focused -- \
  tests/acceptance/applications/javascriptEndpointCandidateCli.test.ts \
  tests/acceptance/applications/javascriptUnavailableHtmlCli.test.ts
```

O primeiro caso de `javascriptEndpointCandidateCli.test.ts` recebe os candidatos extras `/accounts`, `/local-accounts` e `/private`. O diagnóstico reproduziu a mesma interpretação na fonte TypeScript e no JavaScript compilado: certos efeitos globais/protótipos fazem chamadas `Map.get` aparecerem como possíveis endpoints. Isso descarta falha de instalação ou build desatualizado. São falsos positivos possíveis de análise estática, não endpoints observados em execução.

As fontes, testes e lockfile de `morluto/rea` permanecem intactos. O segundo caso desse arquivo e os quatro casos de `javascriptUnavailableHtmlCli.test.ts` passaram. As análises reais de exemplo e a inspeção local CDP também passaram. A suíte completa e os providers nativos opcionais não foram executados.

## Limites verificáveis

Em 27/10/2026, o iniciador `scripts/start-mobile.mjs` foi exercitado com as duas variantes em paralelo no Linux da nuvem, usando um endereço de rede local e API de demonstração isolada. `/status` e os manifestos Android confirmaram nomes, variantes, portas 8081/8082 e o mesmo endereço da API. Os dois bundles Android foram servidos com HTTP 200, cada um com 4.044.819 bytes; o QR code e a URL `exp://` de rede foram observados em terminal interativo. Foram verificados os erros de variante inválida, IP que não pertence à máquina, API inacessível e porta já ocupada. Os arquivos `.cmd` foram revisados quanto a caminhos com espaços, propagação de erro e preservação de `.data\demo`; não foram executados em uma máquina Windows. O teste do Expo na nuvem usou `EXPO_OFFLINE=1` para evitar consultas opcionais externas. A compatibilidade da versão atual do Expo Go da Google Play com SDK 58 não foi confirmada por acesso à loja neste ambiente.

- Não foram executados builds APK/AAB/IPA, assinatura, instalação em aparelhos, testes de GPS em dispositivo, push ou publicação nas lojas. Os quatro bundles e manifestos verificam o fluxo de desenvolvimento JavaScript/Expo, não todo o runtime nativo.
- O painel web e a API foram exercitados localmente; não houve implantação pública.
- O Chromium encontrou `ERR_CERT_AUTHORITY_INVALID` ao navegar diretamente para Machine. A validação TLS não foi desativada. A coleta pública usou curl com conexão validada; a análise REA foi estática sobre o HTML. Não se afirma observação dos painéis privados nem do comportamento de corridas na Machine.
- O `install_script`, o `start_skill` e a lista de repositórios são salvos no rascunho do ambiente. A publicação pelo produto e a restauração em uma tarefa nova permanecem etapas distintas, não testadas aqui.
- A CLI REA está instalada; o MCP não foi registrado dinamicamente nesta conversa.

Evidências locais: `/workspace/.rea-tools/install-repeatability.log`, `notes-analysis.json`, `browser-analysis.json`, `machine-public-analysis.json`, `admin-smoke.mjs` e capturas `admin-desktop.png`/`admin-mobile.png`. Esses arquivos são auxiliares de desenvolvimento, sem credenciais de serviços externos.
