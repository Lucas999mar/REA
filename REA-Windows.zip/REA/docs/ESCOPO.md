# REA Mobilidade — escopo e origem das decisões

A primeira versão implementa um produto próprio com o fluxo solicitado: aplicativos Android/iOS de passageiro e motorista, e superadmin web, todos ligados à mesma API.

## Referência e evidências

- Ferramenta instalada: código oficial `morluto/rea`, checkout `/workspace/rea-toolkit`, commit `1081008c9dba4b895c90faac504d14bd5dd39758` (6.7.0).
- Referência indicada pelo usuário: `https://machine.global/`.
- A consulta pública inicial retornou `CONNECT tunnel failed, response 403` no proxy de saída. O domínio foi incluído no rascunho de rede. Em 25/10/2026, a consulta HTTPS pública já funcionou; foram examinadas a homepage e as páginas dos apps, gestão e mobilidade. Veja [as evidências e a comparação](REFERENCIA-MACHINE.md).
- Nenhum código privado, binário de aplicativo, API autenticada ou painel privado da Machine foi obtido. O HTML público da homepage também foi analisado estaticamente pela CLI REA. Esta implementação segue requisitos do usuário e decisões próprias; não é uma reconstrução comprovada da arquitetura ou da totalidade dos recursos da Machine.
- A instalação da ferramenta REA não concede acesso a sistemas privados. Análises posteriores poderão usar páginas públicas acessíveis, artefatos fornecidos ou ambientes de teste autorizados.

## Fluxo implementado para validação

1. Passageiro e motorista se cadastram em seus respectivos apps.
2. Superadmin aprova o motorista e define tarifas e comissão.
3. Motorista fica disponível. Passageiro seleciona origem, destino e categoria e recebe estimativa.
4. Passageiro solicita a corrida. Somente um motorista pode aceitá-la.
5. Motorista registra chegada, início e conclusão; os outros clientes recebem o estado atualizado.
6. Passageiro avalia a corrida concluída. Histórico e indicadores refletem os dados persistidos.

A API é a autoridade para identidade, autorização, tarifa e transições. O painel web recebe eventos SSE; os apps atualizam o estado periodicamente enquanto ativos. Isso não equivale a notificações push ou operação em segundo plano.

## Limites da primeira versão

- Locais de teste em São Paulo e distâncias estimadas; não há geocodificação, trânsito ou cálculo de trajeto viário por provedor de mapas.
- Pagamento em dinheiro é apenas registrado; não há cobrança, repasse bancário ou integração Pix/cartão.
- Localização do motorista depende da permissão e do app em primeiro plano; sem promessa de rastreamento em segundo plano.
- O superadmin aprova cadastros, mas não verifica documentos, CNH ou identidade em serviços externos.
- Não inclui central de suporte, chat, viagens agendadas, cupons, múltiplas cidades ou precificação dinâmica.
- SQLite atende desenvolvimento e demonstração em uma instância. Operação comercial exige infraestrutura, monitoramento, backups e revisão específica de segurança, privacidade e escala.
- Exportar bundles Android/iOS verifica empacotamento JavaScript. APK/AAB/IPA, assinatura, testes em dispositivos e publicação nas lojas são etapas distintas.

## Próxima análise com REA

Para aprofundar a análise além do material público, usar um ambiente de teste autorizado ou artefatos fornecidos e registrar evidências por funcionalidade: cadastro, solicitação, distribuição, chegada, viagem, pagamento, histórico e administração. Separar sempre observação direta, inferência e lacuna. Comparar os contratos e comportamentos antes de ampliar o aplicativo.
