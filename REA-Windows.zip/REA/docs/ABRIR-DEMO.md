# Abrir o REA no seu computador

Este passo a passo executa o painel superadmin **no seu Windows**. O ambiente de nuvem usado para desenvolver o projeto não é um site público e seus endereços internos não podem ser abertos no seu computador.

## Windows: primeira execução

1. Instale o **Node.js 24.22.1 LTS para Windows**, com npm, pelo [site oficial](https://nodejs.org/). Se já usa uma versão 24.x mais recente, ela também serve. As versões 22.x, 24.22.0 e 25.x não são aceitas por este projeto.
2. Extraia **todos os arquivos** do pacote ZIP para uma pasta, por exemplo `Documentos\REA`. Não execute o iniciador diretamente de dentro do ZIP.
3. Abra a pasta extraída. Se ela contiver `INICIAR-REA.cmd`, dê dois cliques nele. O iniciador do projeto também está em `scripts\start-demo.cmd` e pode ser aberto diretamente.
4. Aguarde a instalação das dependências e a compilação. A primeira execução precisa de internet. Deixe a janela aberta.
5. Quando aparecer a mensagem **REA API em 127.0.0.1:3001 · demonstração local**, abra o navegador **nesse mesmo computador** e digite `http://127.0.0.1:3001` na barra de endereço.

O endereço acima só funciona depois que você iniciar o REA localmente. Ele não é um link para o ambiente desta conversa.

No painel, clique em **Preencher acesso de demonstração** e depois entre na conta. Você também pode usar:

- E-mail: `admin@rea.local`
- Senha de demonstração: `ReaDemo!2026`

São contas fictícias locais. Não representam acesso à Machine ou a qualquer serviço externo.

## O que você pode navegar

O painel possui visão geral, corridas, detalhes de cada corrida, motoristas, passageiros e tarifas da operação. Há corridas fictícias para explorar as telas. As alterações ficam no banco local `.data\demo` e continuam disponíveis na próxima execução.

As interfaces de passageiro e motorista são aplicativos Android/iOS separados; elas não são páginas deste painel. Seus códigos estão em `apps\mobile`, com instruções próprias no README dessa pasta. Este iniciador abre o serviço necessário para o superadmin e a API; ele não instala aplicativos no celular.

Para abrir os dois no Android pelo Expo Go, siga [o guia dos aplicativos no Android](ABRIR-APPS-ANDROID.md), usando os novos atalhos na pasta do projeto.

## Encerrar e abrir novamente

Para encerrar, use **Ctrl+C** na janela do servidor. Se o Windows perguntar se deve finalizar o arquivo em lotes, confirme. Para abrir novamente, execute o mesmo iniciador. Ele não apaga o banco de demonstração.

Se houver erro de porta ocupada, verifique se outra janela do REA já está aberta. Use a instância existente ou encerre-a antes de iniciar outra. Se houver erro de versão do Node, instale a versão indicada e abra uma nova janela do iniciador. Se a instalação falhar por rede, confira sua conexão e execute novamente.

## macOS ou Linux

Com o Node.js compatível e npm instalados, abra o terminal na pasta extraída e execute:

```bash
bash scripts/start-demo.sh
```

Quando o servidor confirmar que está pronto, abra o endereço local indicado acima no navegador do mesmo computador.

Este pacote é uma demonstração de desenvolvimento. Usa contas conhecidas e dados fictícios, não processa pagamentos e não deve ser exposto como serviço comercial.
