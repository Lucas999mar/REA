# Ambiente de desenvolvimento e análise

## Diretórios e reprodução

- `/workspace/REA`: sistema de mobilidade e aplicativos.
- `/workspace/rea-toolkit`: ferramenta oficial `morluto/rea`, commit `1081008c9dba4b895c90faac504d14bd5dd39758`.
- `/workspace/.rea-tools`: Node/npm locais, ativação, wrapper da CLI, caches e evidências de validação.

Cada tarefa de nuvem já é isolada. Use os checkouts existentes; não crie Git worktrees sem pedido explícito.

A instalação reutilizável está em `/workspace/.rea-tools/install-environment.sh` e é salva no campo `install_script` das configurações. Ela verifica o SHA-256 do arquivo oficial do Node quando necessário, instala dependências pelos lockfiles e compila o runtime REA e o painel. Não faz reset de checkouts, não modifica as fontes do toolkit e não instala analisadores nativos opcionais.

O campo `start_skill` registra ativação, inicialização da API/painel, execução das variantes móveis e checagens locais. O snapshot pode conservar arquivos e dependências, mas não processos; a API, o Metro e o navegador precisam ser iniciados em cada tarefa quando necessários.

## CLI REA

```bash
source /workspace/.rea-tools/activate.sh
rea --version
rea analyze-javascript-application \
  /workspace/rea-toolkit/website/public/examples/notes-electron --json
```

O exemplo Notes valida a instalação, sem constituir análise da Machine. A CLI possui os mesmos fluxos de análise suportados pelo MCP, mas não adiciona ferramentas dinamicamente à conversa. Não foi alterada a configuração global do cliente Codex.

Para observação de uma página autorizada, use um Chromium com perfil separado e CDP em loopback. O ambiente tem `/usr/bin/chromium`. A inspeção foi validada em uma página local de exemplo com `rea list-browser-targets` e `rea inspect-web-page`. O `targetId` deve ser obtido do navegador atual; não reutilize um ID de uma execução anterior.

```bash
rea list-browser-targets http://127.0.0.1:9222 --json
rea inspect-web-page http://127.0.0.1:9222 TARGET_ID --observation-ms 800 --json
```

## Rede e publicação

O domínio `machine.global` foi acrescentado ao rascunho de rede, preservando os presets de gerenciadores de pacotes. Gravar o rascunho não aplica nem publica a configuração. Revise e salve nas configurações do ambiente; depois publique para criar a versão reutilizável. A consulta HTTPS pública foi repetida em 25/10/2026 e passou. Isso confirma esse acesso na máquina atual, sem comprovar publicação do ambiente.

Não foram solicitadas ou incluídas credenciais da Machine. As páginas públicas foram consultadas e o HTML público da homepage foi analisado pela CLI. Não há acesso aos seus apps privados, painéis ou backend. Para estudar esses fluxos, serão necessários artefatos ou um ambiente de teste autorizado. Não envie senhas pelo chat.

A aplicação criada está no checkout originalmente vazio `Lucas999mar/REA`; nenhum push para GitHub foi executado. O toolkit adicional é mantido em checkout próprio. A restauração em uma tarefa nova só estará comprovada após publicação e validação nessa tarefa.

## Expo na nuvem

A ativação define `EXPO_NO_TELEMETRY=1` e direciona o diretório de estado do Expo e o cache para caminhos graváveis em `/workspace/.rea-tools`, usando o override de shell `__UNSAFE_EXPO_HOME_DIRECTORY` fornecido pelo CLI e `XDG_CACHE_HOME`. O `HOME` não é alterado; nenhuma credencial é copiada. Esse override fica no shell de preparação, nunca no `.env` do aplicativo. Sem ele, o manifesto nativo tentava gravar em `/home/agent/.expo`, que é somente leitura.

Para testes não interativos: `CI=1 npm run start:rider -- --offline --port 8081` e `CI=1 npm run start:driver -- --offline --port 8082`. Omita `CI=1` para usar recarga automática no desenvolvimento. Não combine `--offline` com `--localhost`: esta versão do Expo trata os dois como opções mutuamente exclusivas.

O Chromium desta imagem aceita as páginas locais usadas na validação. A navegação direta para Machine encontrou `ERR_CERT_AUTHORITY_INVALID`; não foi desativada a validação TLS. A consulta pública foi feita com curl, que validou a conexão, e a análise REA usou o HTML local obtido dessa forma. Inspeção CDP externa depende da configuração de confiança apropriada no navegador.
