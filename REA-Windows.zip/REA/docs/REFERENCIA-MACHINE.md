# Referência pública: Machine

Consulta realizada em **25/10/2026**. O bloqueio inicial do proxy foi resolvido: foi possível obter, por HTTPS e sem autenticação, a homepage e quatro páginas públicas de produto.

Este documento registra o que o material comercial anuncia. Não representa inspeção de aplicativos instalados, painel autenticado, tráfego de uma corrida, código privado ou banco de dados da Machine. A implementação REA Mobilidade é própria; não copia código, marca ou recursos visuais da referência.

## Fontes consultadas

| Página pública | Conteúdo observado |
| --- | --- |
| [Homepage](https://machine.global/) | Plataforma white label de mobilidade e entrega; apps de passageiro e condutor; painel de gestão e de empresa; personalização, integrações e API. |
| [App passageiro](https://machine.global/app-passageiro) | Categorias e tarifas, formas de pagamento, negociação de preço, acompanhamento, dados do condutor, compartilhamento de localização, avaliações, favoritos/bloqueios e NPS. |
| [App condutor](https://machine.global/app-condutor) | Ofertas com preço/distância/local, aceite, aviso sonoro, áreas de tarifa dinâmica, desafios/recompensas, gráficos de ganhos e preferências de trabalho. |
| [Painel de gestão](https://machine.global/painel-gestao) | Corridas e motoristas em tempo real, mapa, indicadores, relatórios CSV, configuração comercial, áreas de cobertura e controle financeiro. |
| [Mobilidade](https://machine.global/mobilidade) | Categorias configuráveis, despacho automático, marca própria, carteira de créditos, cupons/cashback e expansão para cidades. |

As páginas também apontam para um [painel de empresa](https://machine.global/painel-empresa), [preços de mobilidade](https://machine.global/precos-mobilidade), [suporte](https://suporte.machine.global/hc/pt-br) e [entrada no painel](https://meupaineldegestao.com.br/). Esses destinos não foram acessados nesta consulta. Nenhum formulário, contato comercial, cadastro ou login foi enviado.

## Requisitos anunciados por perfil

### Passageiro

O site anuncia apps iOS/Android com marca própria, seleção de categorias, preço e pagamento configuráveis, acompanhamento da corrida e informações do motorista. Também descreve compartilhamento de localização, avaliação por estrelas, favorito/bloqueio de motorista, pesquisa NPS e uma categoria de negociação de preço. A homepage menciona histórico e suporte direto.

### Motorista

As ofertas apresentam valor, distância e local, com aceite e sinal sonoro. O material descreve áreas com multiplicadores de tarifa dinâmica, desafios que geram créditos, gráficos de ganhos por período, preferências de formas de pagamento/categorias e modo escuro.

### Gestão

O painel é apresentado como central de corridas, motoristas, solicitações e receita. Anuncia mapa com posições, contadores, alertas de demanda por região, relatórios filtrados e CSV, histórico de corridas/pagamentos e desempenho por motorista. Há configuração de preços, taxas, categorias, pagamentos, cupons e áreas de cobertura. A parte financeira inclui repasses automáticos, extratos e carteiras de crédito.

O termo usado no site é **painel de gestão**. A existência de uma hierarquia interna chamada `superadmin`, seus privilégios exatos e eventual suporte multiempresa não foi demonstrada por essas páginas. No REA Mobilidade, `admin` corresponde ao papel solicitado pelo usuário.

## Comparação com a primeira versão REA Mobilidade

| Tema anunciado | Situação da implementação atual |
| --- | --- |
| Apps de passageiro e motorista + gestão web | Dois apps Expo/React Native por variante e painel React, usando API compartilhada. Builds nativos assinados e testes em aparelhos são etapas separadas. |
| Solicitar, aceitar e acompanhar corridas | Ciclo persistido com autorização por perfil; API é a autoridade. Apps consultam a cada três segundos em primeiro plano; painel usa SSE. |
| Despacho automático | A versão atual lista solicitações elegíveis para aceite; não implementa algoritmo de despacho por proximidade, rodízio, prioridade ou SLA de dois segundos. |
| Categorias e preço | Econômico e Conforto com parâmetros de tarifa/comissão editáveis; não há categorias arbitrárias, negociação ou tarifa dinâmica por região. |
| Mapas e acompanhamento | Localização opcional em primeiro plano e representação esquemática no painel; não há geocodificação, trânsito ou roteamento viário por provedor. |
| Histórico e avaliação | Histórico persistido e avaliação por estrelas; favoritos, bloqueios e NPS ainda não implementados. |
| Pagamentos, carteira e repasses | Registra pagamento em dinheiro. Não cobra, não transfere dinheiro nem mantém carteira financeira. |
| Indicadores e relatórios | Indicadores, histórico e visualizações locais; sem exportação CSV e sem relatórios financeiros completos. |
| Cupons, cashback, desafios e publicidade | Não implementados. |
| Cobertura e múltiplas cidades | Locais de teste em São Paulo; sem gestão de regiões/cidades. |
| Personalização white label | Nomes e identificadores próprios dos apps; sem construtor comercial para personalização de marcas e operações pelo painel. |

## O que ainda exige evidência

O site anuncia despacho em até dois segundos e disponibilidade de 99,9%. Esses números são afirmações comerciais, não medições desta análise. Não foi verificada a estabilidade, segurança, desempenho ou disponibilidade da Machine.

Também permanecem desconhecidos os contratos reais de API, protocolos de sincronização, algoritmos de distribuição, cálculo de preço, políticas de cancelamento, provedores de mapas/pagamentos, modelo de banco, permissões administrativas e comportamento offline/segundo plano. A existência de funcionalidades no material público não revela sua implementação.

Para reconstrução orientada por comportamento, o próximo passo é observar um ambiente de teste autorizado ou artefatos fornecidos, com cenários de cadastro, solicitação, concorrência no aceite, chegada, início, conclusão, cancelamento e pagamento. O acesso público obtido aqui não concede acesso às áreas privadas.

## Identidade dos documentos consultados

SHA-256 do HTML recebido nesta consulta; as páginas públicas podem mudar:

| Caminho | SHA-256 |
| --- | --- |
| `/` | `77f1559d0253cfac8a69f243b5f3a29f6e03dd6478937229e95dcd8403486678` |
| `/app-passageiro` | `d71606e692c4847a71f26ec71a4019f5cd29a44fc90fdec612d4752a7c7e7ec5` |
| `/app-condutor` | `c0394993600a746e6e139c4f06b490940e2ab15ddb968b1bbcf0589bc54a9e89` |
| `/painel-gestao` | `e71872da94b7c5cd5869c4ffcbe6be7cd61a9c358affc316a89da23f6a9b9bef` |
| `/mobilidade` | `541d7c25384a6abc795814c12c77200592c1d5012eda5311c57ef55673b8432d` |
