# Abrir passageiro e motorista no Android

Os aplicativos estão em `apps\mobile`. Nesta fase, abra-os pelo **Expo Go**, instalado pela Google Play. Eles ainda não são APKs separados e não aparecem como páginas dentro do superadmin. O projeto usa Expo SDK 58; o Expo Go instalado precisa aceitar essa versão.

## Adicionar os atalhos ao pacote que você já baixou

Se recebeu `REA-Android-Atalhos.zip`, extraia o conteúdo da pasta `REA` **dentro da mesma pasta REA que você já usa**. Aceite substituir `scripts\start-demo.cmd` e os documentos incluídos. Ao terminar, `ABRIR-PASSAGEIRO.cmd`, `ABRIR-MOTORISTA.cmd` e `INICIAR-REA-REDE.cmd` devem ficar ao lado de `INICIAR-REA.cmd`. Não crie uma segunda pasta `REA` dentro da primeira.

O complemento não contém banco nem credenciais pessoais. Os seus dados continuam em `.data\demo`; não mova nem apague essa pasta.

## Abrir no celular

1. Instale **Expo Go** pela Google Play e conecte o Android e o computador à mesma rede local. O computador pode estar conectado por cabo ao mesmo roteador.
2. Encerre a janela antiga de `INICIAR-REA.cmd` com **Ctrl+C**. Se o Windows perguntar se deseja finalizar o arquivo em lotes, confirme. Apenas fechar a aba do navegador não encerra o servidor.
3. Abra **`INICIAR-REA-REDE.cmd`**. Aguarde a instalação das dependências, a compilação e a mensagem **REA API em 0.0.0.0:3001**. Mantenha essa janela aberta. Ela usa o mesmo banco do superadmin.
4. Abra **`ABRIR-PASSAGEIRO.cmd`**. Se aparecer uma lista de conexões, digite o número da sua conexão Wi-Fi ou Ethernet. O iniciador escolhe o endereço automaticamente quando existe apenas uma opção.
5. Aguarde o QR code. No **Expo Go do Android**, toque em **Scan QR code / Escanear QR code** e leia o código. A primeira abertura pode demorar enquanto o aplicativo é compilado.
6. Para ver o outro aplicativo, abra **`ABRIR-MOTORISTA.cmd`** no Windows e leia o QR code dessa janela pelo Expo Go. No mesmo celular, volte à tela inicial do Expo Go para trocar de aplicativo.

Se o Windows pedir acesso de rede para Node.js, permita nas **redes privadas**. Não é necessário desligar o firewall. Não encaminhe essas portas no roteador nem exponha esta demonstração à internet.

| App | E-mail de demonstração | Senha |
| --- | --- | --- |
| Passageiro | `passageiro@rea.local` | `ReaDemo!2026` |
| Motorista | `motorista@rea.local` | `ReaDemo!2026` |

Você também pode usar o botão de preenchimento da conta de demonstração dentro de cada app. No computador, o superadmin continua em `http://127.0.0.1:3001`, com `admin@rea.local` e a mesma senha de demonstração.

## Experimentar uma corrida

No passageiro, escolha origem e destino, consulte o preço e solicite a corrida. No motorista, fique online, aceite a solicitação, indique a chegada, inicie e finalize. Volte ao passageiro para conferir e avaliar. O superadmin acompanha as mesmas informações.

Um único celular permite alternar entre os dois apps. Com dois celulares Android, você pode deixar passageiro e motorista abertos ao mesmo tempo. As atualizações acontecem enquanto cada app está em primeiro plano; não há notificações com o app fechado.

## Se não abrir

- **API não respondeu:** deixe `INICIAR-REA-REDE.cmd` aberto e espere a mensagem REA API. Não use o iniciador antigo nessa hora, pois ele atende somente o computador.
- **QR abre, mas o app não carrega:** confirme o Wi-Fi e a liberação do Node.js no firewall da rede privada. Redes de convidados podem bloquear a comunicação entre dispositivos. Havendo VPN ou vários adaptadores, confira a conexão escolhida.
- **Teste de conexão:** a janela do app mostra um endereço como `http://192.168.1.20:3001/api/health`. Digite o endereço exibido no navegador do celular. Deve aparecer `{"ok":true}`. Esse IP é um exemplo; use o que estiver na sua janela.
- **Porta ocupada:** encerre a janela antiga do servidor ou do mesmo app antes de abrir outra. A API usa a porta 3001; passageiro, 8081; motorista, 8082.
- **Expo Go informa SDK incompatível:** atualize o Expo Go pela Google Play. Se continuar, informe a mensagem completa; será necessário um Expo Go compatível com SDK 58 ou um build próprio. Não há APK separado incluído neste pacote.

Feche os dois apps com **Ctrl+C** nas respectivas janelas e depois encerre o servidor. Abrir os atalhos novamente preserva o banco. A primeira preparação exige internet; o código QR aponta para o seu computador, não para o ambiente desta conversa.

Os iniciadores e manifestos podem ser verificados no ambiente de desenvolvimento; isso não substitui a validação em um aparelho Android real. Ainda não houve instalação e teste em aparelho por parte do desenvolvimento.
