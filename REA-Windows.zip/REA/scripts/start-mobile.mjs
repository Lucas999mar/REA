import { existsSync } from 'node:fs';
import { networkInterfaces } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer } from 'node:net';
import { createInterface } from 'node:readline/promises';
import { spawn } from 'node:child_process';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const mobileRoot = join(root, 'apps', 'mobile');
const variant = process.argv[2];
const port = variant === 'driver' ? 8082 : 8081;
const label = variant === 'driver' ? 'Motorista' : 'Passageiro';

function lanAddresses() {
  return Object.entries(networkInterfaces()).flatMap(([name, addresses]) =>
    addresses.filter(entry => entry.family === 'IPv4' && !entry.internal &&
      !entry.address.startsWith('169.254.')).map(entry => ({ name, address: entry.address }))
  ).filter((entry, index, all) => all.findIndex(other => other.address === entry.address) === index);
}

async function chooseAddress() {
  const addresses = lanAddresses();
  if (!addresses.length) throw new Error('Conecte o computador a mesma rede Wi-Fi do celular e tente novamente.');
  if (process.env.REA_LAN_IP) {
    const selected = addresses.find(entry => entry.address === process.env.REA_LAN_IP);
    if (!selected) throw new Error('REA_LAN_IP precisa ser um IPv4 deste computador.');
    return selected.address;
  }
  if (addresses.length === 1) return addresses[0].address;
  console.log('\nEscolha a conexao usada para acessar a mesma rede do celular:');
  addresses.forEach((entry, index) => console.log(`  ${index + 1}. ${entry.name}: ${entry.address}`));
  const input = createInterface({ input: process.stdin, output: process.stdout });
  try {
    while (true) {
      const answer = (await input.question('Digite o numero da conexao Wi-Fi ou Ethernet: ')).trim();
      if (/^[1-9]\d*$/.test(answer) && addresses[Number(answer) - 1]) return addresses[Number(answer) - 1].address;
      console.log('Escolha um dos numeros listados acima.');
    }
  } finally { input.close(); }
}

async function checkPort() {
  await new Promise((resolve, reject) => {
    const server = createServer();
    server.once('error', error => reject(new Error(`A porta ${port} nao esta disponivel (${error.code}). Feche a janela anterior do app ${label} e tente novamente.`)));
    server.listen({ port, host: '0.0.0.0', exclusive: true }, () => server.close(resolve));
  });
}

async function main() {
  const [major, minor, patch] = process.versions.node.split('.').map(Number);
  if (major !== 24 || minor < 22 || (minor === 22 && patch < 1)) {
    throw new Error('Use Node.js 24.22.1 ou uma versao 24.x mais recente, inferior a 25.');
  }
  if (!['rider', 'driver'].includes(variant)) throw new Error('Abra ABRIR-PASSAGEIRO.cmd ou ABRIR-MOTORISTA.cmd.');
  const cli = join(mobileRoot, 'node_modules', 'expo', 'bin', 'cli');
  if (!existsSync(cli)) throw new Error('Primeiro abra INICIAR-REA-REDE.cmd e aguarde a preparacao terminar.');
  const address = await chooseAddress();
  const apiUrl = `http://${address}:3001`;
  try {
    const response = await fetch(`${apiUrl}/api/meta`, { signal: AbortSignal.timeout(4000) });
    if (!response.ok || (await response.json()).demoMode !== true) throw new Error('API sem demonstracao');
  } catch {
    throw new Error(`A demonstracao nao respondeu em ${apiUrl}. Feche o servidor antigo e abra INICIAR-REA-REDE.cmd. Se houver varias conexoes, selecione a rede do celular.`);
  }
  await checkPort();
  console.log(`\nREA ${label} - Android com Expo Go`);
  console.log(`API compartilhada com o superadmin: ${apiUrl}`);
  console.log(`No navegador do celular, ${apiUrl}/api/health deve mostrar {"ok":true}.`);
  console.log('Mantenha computador e celular na mesma rede. Permita Node.js nas redes privadas se o Windows solicitar.');
  console.log('Abra Expo Go no Android e escaneie o QR code que aparecera abaixo.');
  console.log(`Acesso: ${variant === 'driver' ? 'motorista' : 'passageiro'}@rea.local / ReaDemo!2026`);
  console.log('Mantenha esta janela e a janela INICIAR-REA-REDE abertas. Ctrl+C encerra este app.\n');
  const child = spawn(process.execPath, [cli, 'start', '--go', '--lan', '--port', String(port)], {
    cwd: mobileRoot,
    stdio: 'inherit',
    env: {
      ...process.env,
      NODE_ENV: 'development',
      EXPO_NO_TELEMETRY: '1',
      APP_VARIANT: variant,
      EXPO_PUBLIC_API_URL: apiUrl,
      EXPO_PUBLIC_DEMO_MODE: '1',
      REACT_NATIVE_PACKAGER_HOSTNAME: address,
    },
  });
  const stop = () => { child.kill('SIGINT'); };
  process.once('SIGINT', stop);
  process.once('SIGTERM', stop);
  child.once('error', error => { console.error(`Nao foi possivel iniciar o Expo: ${error.message}`); process.exitCode = 1; });
  child.once('exit', (code, signal) => {
    process.removeListener('SIGINT', stop);
    process.removeListener('SIGTERM', stop);
    process.exitCode = signal === 'SIGINT' ? 0 : (code ?? 1);
  });
}

main().catch(error => { console.error(`\n${error.message}\n`); process.exitCode = 1; });
