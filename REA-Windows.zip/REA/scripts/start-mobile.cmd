@echo off
setlocal
cd /d "%~dp0.."
if errorlevel 1 goto :failed
where node >nul 2>nul
if errorlevel 1 goto :missing_node
node scripts\start-mobile.mjs "%~1"
if errorlevel 1 goto :failed
exit /b 0

:missing_node
echo Instale Node.js 24.22.1 LTS com npm e execute novamente.
pause
exit /b 1

:failed
echo Leia a mensagem acima e consulte docs\ABRIR-APPS-ANDROID.md.
pause
exit /b 1
