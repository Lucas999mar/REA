#!/usr/bin/env bash
set -euo pipefail

cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."

if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  printf '%s\n' 'Instale Node.js 24.22.1 LTS com npm e execute este arquivo novamente.' >&2
  exit 1
fi
if ! node -e 'const [major, minor, patch] = process.versions.node.split(".").map(Number); if (major !== 24 || minor < 22 || (minor === 22 && patch < 1)) process.exit(1)'; then
  printf '%s\n' 'Este projeto precisa de Node.js 24.22.1 ou uma versão 24.x mais recente (inferior a 25).' >&2
  node --version >&2
  exit 1
fi

export NODE_ENV=development
export REA_DEMO_MODE=1
export HOST=127.0.0.1
export PORT=3001
export DATA_DIR=.data/demo

printf '%s\n' 'Preparando a demonstração local. A primeira execução precisa de internet.'
npm ci --include=dev --no-audit --no-fund
npm run build
printf '\n%s\n' 'Iniciando REA na porta local 3001. Mantenha este terminal aberto.' 'Leia docs/ABRIR-DEMO.md para abrir o painel no navegador deste computador.' 'Use Ctrl+C para encerrar. Os dados de demonstração serão preservados.'
exec npm start
