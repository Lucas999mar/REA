@echo off
setlocal
cd /d "%~dp0.."
if errorlevel 1 goto :failed

where node >nul 2>nul
if errorlevel 1 goto :missing_node
where npm >nul 2>nul
if errorlevel 1 goto :missing_node

node -e "const v = process.versions.node.split('.').map(Number); if (v[0] !== 24 || v[1] < 22 || (v[1] === 22 && v[2] < 1)) process.exit(1)"
if errorlevel 1 goto :wrong_node

set "NODE_ENV=development"
set "REA_DEMO_MODE=1"
set "HOST=127.0.0.1"
set "PORT=3001"
set "DATA_DIR=.data\demo"

echo Preparando a demonstracao local.
echo A primeira execucao precisa de internet. Aguarde esta janela terminar a preparacao.
call npm ci --include=dev --no-audit --no-fund
if errorlevel 1 goto :failed
call npm run build
if errorlevel 1 goto :failed

echo.
echo Iniciando REA na porta local 3001. Mantenha esta janela aberta.
echo Quando aparecer REA API em 127.0.0.1:3001, abra http://127.0.0.1:3001 no navegador deste computador.
echo Login de demonstracao: admin@rea.local - Senha: ReaDemo!2026
echo Use Ctrl+C para encerrar. Os dados de demonstracao serao preservados.
call npm start
if errorlevel 1 goto :failed
exit /b 0

:missing_node
echo.
echo Instale Node.js 24.22.1 LTS para Windows com npm, feche esta janela e execute novamente.
echo O instalador oficial esta em https://nodejs.org/
pause
exit /b 1

:wrong_node
echo.
echo Este projeto precisa de Node.js 24.22.1 ou uma versao 24.x mais recente, inferior a 25.
echo Versao encontrada:
node --version
pause
exit /b 1

:failed
echo.
echo Nao foi possivel iniciar a demonstracao. Leia a mensagem de erro acima.
echo Se a porta 3001 estiver ocupada, encerre a outra instancia REA e tente novamente.
echo Nenhum banco de dados existente foi removido por este iniciador.
pause
exit /b 1
