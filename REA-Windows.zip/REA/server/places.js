export const places = [
  { id: 'paulista', name: 'Avenida Paulista', address: 'MASP · Av. Paulista, 1578', lat: -23.5614, lng: -46.6559 },
  { id: 'ibirapuera', name: 'Parque Ibirapuera', address: 'Portão 3 · Av. Pedro Álvares Cabral', lat: -23.5874, lng: -46.6576 },
  { id: 'pinheiros', name: 'Estação Pinheiros', address: 'Rua Capri, 145 · Pinheiros', lat: -23.5673, lng: -46.7018 },
  { id: 'congonhas', name: 'Aeroporto de Congonhas', address: 'Av. Washington Luís · Vila Congonhas', lat: -23.6261, lng: -46.6564 },
  { id: 'republica', name: 'Praça da República', address: 'República · Centro', lat: -23.5436, lng: -46.6428 },
  { id: 'itaim', name: 'Itaim Bibi', address: 'Rua João Cachoeira, 500', lat: -23.5847, lng: -46.6767 },
  { id: 'liberdade', name: 'Praça da Liberdade', address: 'Praça da Liberdade · Centro', lat: -23.5553, lng: -46.6351 },
  { id: 'vilamadalena', name: 'Vila Madalena', address: 'Praça Benedito Calixto', lat: -23.5584, lng: -46.6817 },
];
export const defaultSettings = { baseFareCents: 550, perKmCents: 220, minimumFareCents: 1000, commissionPercent: 15, comfortMultiplier: 1.35 };
export const activeStatuses = ['requested', 'accepted', 'arrived', 'in_progress'];
