import express from 'express';
import { randomUUID } from 'node:crypto';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { existsSync } from 'node:fs';
import { openDatabase } from './database.js';
import { hashPassword, verifyPassword, newToken, tokenHash, requestToken } from './auth.js';
import { places, activeStatuses } from './places.js';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const sessionAgeMs = 7 * 24 * 3600_000;
const terminalStatuses = ['completed', 'cancelled'];
const publicUser = (row) => ({ id: row.id, name: row.name, email: row.email, role: row.role, phone: row.phone, approved: !!row.approved, online: !!row.online, vehicle: row.vehicle_json ? JSON.parse(row.vehicle_json) : null, location: row.lat === null ? null : { lat: row.lat, lng: row.lng } });
class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
const fail = (status, message) => { throw new HttpError(status, message); };
const text = (value, min, max) => typeof value === 'string' && value.trim().length >= min && value.trim().length <= max;

export function createApp({ dbPath = join(process.env.DATA_DIR || join(root, '.data'), 'rea.sqlite'), demoMode = false, allowedOrigins = [] } = {}) {
  const app = express();
  const db = openDatabase(dbPath, demoMode);
  const streams = new Set();
  const authAttempts = new Map();
  const origins = new Set(['http://localhost:5173', 'http://127.0.0.1:5173', ...allowedOrigins]);
  app.disable('x-powered-by');
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'same-origin');
    const origin = req.get('origin');
    const ownOrigin = `${req.protocol}://${req.get('host')}`;
    if (origin && origin !== ownOrigin && !origins.has(origin)) return res.status(403).json({ error: 'Origem da requisição não permitida.' });
    if (origin && origins.has(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Access-Control-Allow-Credentials', 'true');
      res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Client-Type');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, OPTIONS');
    }
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
  });
  app.use(express.json({ limit: '32kb' }));
  app.use('/api', (_req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });
  const getUser = (id) => db.prepare('SELECT * FROM users WHERE id=?').get(id);
  const getSettings = () => JSON.parse(db.prepare('SELECT value FROM settings WHERE id=1').get().value);
  const selectRides = `SELECT r.*, ru.name AS rider_name, du.name AS driver_name, du.vehicle_json AS driver_vehicle, du.lat AS driver_lat, du.lng AS driver_lng FROM rides r JOIN users ru ON ru.id=r.rider_id LEFT JOIN users du ON du.id=r.driver_id`;
  const mapRide = (row) => ({ id: row.id, riderId: row.rider_id, driverId: row.driver_id, riderName: row.rider_name, driverName: row.driver_name, driverVehicle: row.driver_vehicle ? JSON.parse(row.driver_vehicle) : null, origin: JSON.parse(row.origin_json), destination: JSON.parse(row.destination_json), category: row.category, status: row.status, distanceKm: row.distance_km, durationMinutes: row.duration_minutes, totalCents: row.total_cents, commissionCents: row.commission_cents, paymentMethod: row.payment_method, createdAt: row.created_at, updatedAt: row.updated_at, rating: row.rating, driverLocation: row.driver_lat === null || terminalStatuses.includes(row.status) ? null : { lat: row.driver_lat, lng: row.driver_lng } });
  const getRide = (id) => { const row = db.prepare(`${selectRides} WHERE r.id=?`).get(id); return row ? mapRide(row) : null; };
  const activeRide = (field, id) => db.prepare(`SELECT id FROM rides WHERE ${field}=? AND status IN ('requested','accepted','arrived','in_progress')`).get(id);
  const authenticate = (req, _res, next) => {
    const token = requestToken(req);
    if (!token || token.length > 256) return next(new HttpError(401, 'Entre na sua conta para continuar.'));
    const session = db.prepare('SELECT user_id FROM sessions WHERE token_hash=? AND expires_at>?').get(tokenHash(token), Date.now());
    if (!session) return next(new HttpError(401, 'Sua sessão expirou. Entre novamente.'));
    req.user = getUser(session.user_id);
    req.sessionToken = token;
    next();
  };
  const role = (...roles) => (req, _res, next) => roles.includes(req.user.role) ? next() : next(new HttpError(403, 'Seu perfil não permite esta ação.'));
  function notify(type, predicate = () => true) {
    for (const stream of streams) {
      const user = getUser(stream.userId);
      if (user && (user.role === 'admin' || predicate(user))) stream.res.write(`event: change\ndata: ${JSON.stringify({ type })}\n\n`);
    }
  }
  const notifyRide = (ride, type = 'ride') => notify(type, (user) => user.id === ride.riderId || user.id === ride.driverId || (user.role === 'driver' && user.approved && user.online && (ride.status === 'requested' || type === 'ride')));
  function issueSession(req, res, user) {
    const token = newToken();
    db.prepare('DELETE FROM sessions WHERE expires_at<=?').run(Date.now());
    db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES (?,?,?)').run(tokenHash(token), user.id, Date.now() + sessionAgeMs);
    const mobile = req.get('x-client-type') === 'mobile';
    if (!mobile) res.cookie('rea_session', token, { httpOnly: true, sameSite: 'strict', secure: req.secure || process.env.COOKIE_SECURE === '1', path: '/', maxAge: sessionAgeMs });
    return { user: publicUser(user), ...(mobile ? { token } : {}) };
  }
  function quote(body) {
    const origin = places.find((place) => place.id === body.originId);
    const destination = places.find((place) => place.id === body.destinationId);
    if (!origin || !destination || origin.id === destination.id) fail(400, 'Escolha uma origem e um destino diferentes da lista.');
    if (!['economy', 'comfort'].includes(body.category)) fail(400, 'Escolha uma categoria válida.');
    const radians = (degrees) => degrees * Math.PI / 180;
    const a = Math.sin(radians(destination.lat - origin.lat) / 2) ** 2 + Math.cos(radians(origin.lat)) * Math.cos(radians(destination.lat)) * Math.sin(radians(destination.lng - origin.lng) / 2) ** 2;
    const distanceKm = Math.max(1, Math.round(6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)) * 1.25 * 10) / 10);
    const settings = getSettings();
    const multiplier = body.category === 'comfort' ? settings.comfortMultiplier : 1;
    return { origin, destination, category: body.category, distanceKm, durationMinutes: Math.max(5, Math.round(distanceKm / 24 * 60 + 3)), totalCents: Math.round(Math.max(settings.minimumFareCents, settings.baseFareCents + distanceKm * settings.perKmCents) * multiplier) };
  }
  app.get('/api/health', (_req, res) => res.json({ ok: true }));
  app.get('/api/meta', (_req, res) => res.json({ demoMode }));
  app.get('/api/places', (_req, res) => res.json({ places }));
  app.use('/api/auth', (req, _res, next) => {
    if (req.method !== 'POST' || req.path === '/logout') return next();
    const now = Date.now();
    for (const [key, value] of authAttempts) if (value.expires <= now) authAttempts.delete(key);
    const key = req.ip;
    const attempts = authAttempts.get(key) || { count: 0, expires: now + 15 * 60_000 };
    attempts.count++;
    authAttempts.set(key, attempts);
    if (attempts.count > 40) return next(new HttpError(429, 'Muitas tentativas. Aguarde 15 minutos e tente novamente.'));
    next();
  });
  app.post('/api/auth/register', (req, res) => {
    const body = req.body || {};
    if (!text(body.name, 2, 80) || !text(body.email, 5, 254) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email) || typeof body.password !== 'string' || body.password.length < 12 || body.password.length > 128) fail(400, 'Informe nome, e-mail válido e senha de 12 a 128 caracteres.');
    if (!['rider', 'driver'].includes(body.role)) fail(400, 'O cadastro deve ser de passageiro ou motorista.');
    if (body.phone !== undefined && !text(body.phone, 0, 25)) fail(400, 'Telefone inválido.');
    const email = body.email.trim().toLowerCase();
    if (db.prepare('SELECT id FROM users WHERE email=?').get(email)) fail(409, 'Este e-mail já possui uma conta.');
    let vehicle = null;
    if (body.role === 'driver') {
      const candidate = body.vehicle || {};
      if (!text(candidate.model, 2, 60) || !text(candidate.plate, 5, 12) || !text(candidate.color, 2, 30)) fail(400, 'Informe modelo, placa e cor do veículo.');
      vehicle = { model: candidate.model.trim(), plate: candidate.plate.trim().toUpperCase(), color: candidate.color.trim() };
    }
    const id = randomUUID();
    db.prepare('INSERT INTO users(id,name,email,password_hash,role,phone,approved,vehicle_json,created_at) VALUES (?,?,?,?,?,?,?,?,?)').run(id, body.name.trim(), email, hashPassword(body.password), body.role, (body.phone || '').trim(), body.role === 'rider' ? 1 : 0, vehicle ? JSON.stringify(vehicle) : null, new Date().toISOString());
    const user = getUser(id);
    notify('users', (u) => u.id === id);
    res.status(201).json(issueSession(req, res, user));
  });
  const dummyHash = hashPassword('not-a-real-account-password');
  app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body || {};
    if (!text(email, 1, 254) || typeof password !== 'string' || password.length > 128) fail(400, 'Informe e-mail e senha.');
    const user = db.prepare('SELECT * FROM users WHERE email=?').get(email.trim().toLowerCase());
    const valid = verifyPassword(password, user?.password_hash || dummyHash);
    if (!user || !valid) fail(401, 'E-mail ou senha incorretos.');
    res.json(issueSession(req, res, user));
  });
  app.post('/api/auth/logout', authenticate, (req, res) => {
    db.prepare('DELETE FROM sessions WHERE token_hash=?').run(tokenHash(req.sessionToken));
    for (const stream of streams) if (stream.tokenHash === tokenHash(req.sessionToken)) stream.res.end();
    res.clearCookie('rea_session', { httpOnly: true, sameSite: 'strict', path: '/' });
    res.json({ ok: true });
  });
  app.get('/api/auth/me', authenticate, (req, res) => res.json({ user: publicUser(req.user) }));
  app.get('/api/events', authenticate, (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();
    res.write(': connected\n\n');
    const stream = { userId: req.user.id, tokenHash: tokenHash(req.sessionToken), res, heartbeat: null };
    streams.add(stream);
    const heartbeat = setInterval(() => {
      const session = db.prepare('SELECT user_id FROM sessions WHERE token_hash=? AND expires_at>?').get(stream.tokenHash, Date.now());
      if (!session) return res.end();
      res.write(': heartbeat\n\n');
    }, 20_000);
    heartbeat.unref();
    stream.heartbeat = heartbeat;
    req.on('close', () => { streams.delete(stream); clearInterval(heartbeat); });
  });
  app.get('/api/dashboard', authenticate, (req, res) => {
    const user = req.user;
    const where = user.role === 'rider' ? ' WHERE r.rider_id=?' : user.role === 'driver' ? ' WHERE r.driver_id=?' : '';
    const rides = db.prepare(`${selectRides}${where} ORDER BY r.created_at DESC`).all(...(where ? [user.id] : [])).map(mapRide);
    const availableRides = user.role === 'driver' && user.approved && user.online && !activeRide('driver_id',user.id) ? db.prepare(`${selectRides} WHERE r.status='requested' AND r.driver_id IS NULL ORDER BY r.created_at ASC`).all().map(mapRide) : [];
    const completed = rides.filter((r) => r.status === 'completed');
    const stats = { totalRides: rides.length, completedRides: completed.length, activeRides: rides.filter((r) => activeStatuses.includes(r.status)).length, totalRevenueCents: completed.reduce((sum, ride) => sum + ride.totalCents, 0), driverEarningsCents: completed.reduce((sum, ride) => sum + ride.totalCents - ride.commissionCents, 0), onlineDrivers: db.prepare("SELECT COUNT(*) AS count FROM users WHERE role='driver' AND approved=1 AND online=1").get().count, pendingDrivers: user.role === 'admin' ? db.prepare("SELECT COUNT(*) AS count FROM users WHERE role='driver' AND approved=0").get().count : 0 };
    res.json({ user: publicUser(user), rides, availableRides, stats, users: user.role === 'admin' ? db.prepare('SELECT * FROM users ORDER BY created_at DESC').all().map(publicUser) : [], settings: getSettings() });
  });
  app.post('/api/quotes', authenticate, (req, res) => res.json({ quote: quote(req.body || {}) }));
  app.post('/api/rides', authenticate, role('rider'), (req, res) => {
    const body = req.body || {};
    if (body.paymentMethod !== 'cash') fail(400, 'Nesta versão, o pagamento é combinado em dinheiro com o motorista.');
    if (activeRide('rider_id', req.user.id)) fail(409, 'Você já tem uma corrida em andamento.');
    const estimate = quote(body);
    const id = randomUUID();
    const now = new Date().toISOString();
    db.prepare('INSERT INTO rides(id,rider_id,origin_json,destination_json,category,status,distance_km,duration_minutes,total_cents,commission_cents,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)').run(id, req.user.id, JSON.stringify(estimate.origin), JSON.stringify(estimate.destination), estimate.category, 'requested', estimate.distanceKm, estimate.durationMinutes, estimate.totalCents, Math.round(estimate.totalCents * getSettings().commissionPercent / 100), now, now);
    const ride = getRide(id);
    notifyRide(ride);
    res.status(201).json({ ride });
  });
  app.post('/api/rides/:id/accept', authenticate, role('driver'), (req, res) => {
    if (!req.user.approved || !req.user.online) fail(403, 'Seu cadastro precisa estar aprovado e online.');
    if (activeRide('driver_id', req.user.id)) fail(409, 'Conclua sua corrida atual antes de aceitar outra.');
    const result = db.prepare("UPDATE rides SET driver_id=?,status='accepted',updated_at=? WHERE id=? AND status='requested' AND driver_id IS NULL").run(req.user.id, new Date().toISOString(), req.params.id);
    if (!result.changes) fail(409, 'Esta corrida não está mais disponível.');
    const ride = getRide(req.params.id);
    notifyRide(ride);
    res.json({ ride });
  });
  app.post('/api/rides/:id/status', authenticate, (req, res) => {
    const ride = getRide(req.params.id);
    if (!ride) fail(404, 'Corrida não encontrada.');
    const actor = req.user;
    const status = req.body?.status;
    if (actor.role !== 'admin' && actor.id !== ride.riderId && actor.id !== ride.driverId) fail(403, 'Você não tem acesso a esta corrida.');
    if (!['arrived','in_progress','completed','cancelled'].includes(status)) fail(400, 'Status inválido.');
    if (terminalStatuses.includes(ride.status)) fail(409, 'Esta corrida já foi encerrada.');
    if (status === 'cancelled') {
      if (ride.status === 'in_progress' && actor.role !== 'admin') fail(409, 'Uma corrida iniciada só pode ser encerrada pela operação.');
    } else {
      if (actor.role !== 'admin' && (actor.role !== 'driver' || actor.id !== ride.driverId)) fail(403, 'Somente o motorista responsável pode avançar a corrida.');
      const allowedNext = { accepted: 'arrived', arrived: 'in_progress', in_progress: 'completed' };
      if (allowedNext[ride.status] !== status) fail(409, 'Esta mudança de status não é permitida agora.');
    }
    db.prepare('UPDATE rides SET status=?,updated_at=? WHERE id=?').run(status, new Date().toISOString(), ride.id);
    const updated = getRide(ride.id);
    notifyRide(updated);
    res.json({ ride: updated });
  });
  app.post('/api/rides/:id/rating', authenticate, role('rider'), (req, res) => {
    const ride = getRide(req.params.id);
    if (!ride) fail(404, 'Corrida não encontrada.');
    if (ride.riderId !== req.user.id) fail(403, 'Você não pode avaliar esta corrida.');
    if (ride.status !== 'completed') fail(409, 'A corrida precisa estar concluída para receber uma avaliação.');
    if (!Number.isInteger(req.body?.rating) || req.body.rating < 1 || req.body.rating > 5) fail(400, 'A avaliação deve ser de 1 a 5 estrelas.');
    if (ride.rating !== null) fail(409, 'Esta corrida já foi avaliada.');
    db.prepare('UPDATE rides SET rating=?,updated_at=? WHERE id=?').run(req.body.rating, new Date().toISOString(), ride.id);
    const updated = getRide(ride.id);
    notifyRide(updated);
    res.json({ ride: updated });
  });
  app.post('/api/driver/availability', authenticate, role('driver'), (req, res) => {
    if (typeof req.body?.online !== 'boolean') fail(400, 'Informe a disponibilidade.');
    if (req.body.online && !req.user.approved) fail(403, 'Aguarde a aprovação do seu cadastro.');
    if (!req.body.online && activeRide('driver_id', req.user.id)) fail(409, 'Conclua a corrida antes de ficar offline.');
    db.prepare('UPDATE users SET online=? WHERE id=?').run(req.body.online ? 1 : 0, req.user.id);
    notify('availability', (user) => user.id === req.user.id);
    res.json({ user: publicUser(getUser(req.user.id)) });
  });
  app.post('/api/driver/location', authenticate, role('driver'), (req, res) => {
    const { lat, lng } = req.body || {};
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) fail(400, 'Coordenadas inválidas.');
    if (!req.user.approved) fail(403, 'Aguarde a aprovação do seu cadastro.');
    db.prepare('UPDATE users SET lat=?,lng=? WHERE id=?').run(lat, lng, req.user.id);
    const current = activeRide('driver_id', req.user.id);
    if (current) notifyRide(getRide(current.id), 'location');
    else notify('location', (user) => user.id === req.user.id);
    res.json({ user: publicUser(getUser(req.user.id)) });
  });
  app.patch('/api/admin/users/:id', authenticate, role('admin'), (req, res) => {
    const user = getUser(req.params.id);
    if (!user || user.role !== 'driver') fail(404, 'Motorista não encontrado.');
    if (typeof req.body?.approved !== 'boolean') fail(400, 'Informe se o cadastro está aprovado.');
    if (!req.body.approved && activeRide('driver_id', user.id)) fail(409, 'O motorista está em uma corrida.');
    db.prepare('UPDATE users SET approved=?,online=CASE WHEN ?=0 THEN 0 ELSE online END WHERE id=?').run(req.body.approved ? 1 : 0, req.body.approved ? 1 : 0, user.id);
    notify('users', (u) => u.id === user.id);
    res.json({ user: publicUser(getUser(user.id)) });
  });
  app.patch('/api/admin/settings', authenticate, role('admin'), (req, res) => {
    const current = getSettings();
    const body = req.body || {};
    const allowed = Object.keys(current);
    if (Object.keys(body).some((key) => !allowed.includes(key)) || !Object.keys(body).length) fail(400, 'Configuração inválida.');
    const updated = { ...current, ...body };
    for (const key of ['baseFareCents','perKmCents','minimumFareCents']) if (!Number.isInteger(updated[key]) || updated[key] < 0 || updated[key] > 100_000) fail(400, 'As tarifas devem ser valores válidos em centavos.');
    if (!Number.isFinite(updated.commissionPercent) || updated.commissionPercent < 0 || updated.commissionPercent > 50 || !Number.isFinite(updated.comfortMultiplier) || updated.comfortMultiplier < 1 || updated.comfortMultiplier > 3 || updated.minimumFareCents < 100) fail(400, 'Confira comissão (0–50%), multiplicador (1–3) e tarifa mínima.');
    db.prepare('UPDATE settings SET value=? WHERE id=1').run(JSON.stringify(updated));
    notify('settings');
    res.json({ settings: updated });
  });
  app.use('/api', (_req, res) => res.status(404).json({ error: 'Recurso não encontrado.' }));
  const dist = join(root, 'dist');
  if (existsSync(join(dist, 'index.html'))) {
    app.use(express.static(dist));
    app.get('/{*path}', (_req, res) => res.sendFile(join(dist, 'index.html')));
  }
  app.use((error, _req, res, _next) => {
    if (error.type === 'entity.parse.failed') return res.status(400).json({ error: 'JSON inválido.' });
    if (error.type === 'entity.too.large') return res.status(413).json({ error: 'Requisição muito grande.' });
    if (String(error.code || '').startsWith('ERR_SQLITE') && /UNIQUE/.test(error.message)) return res.status(409).json({ error: 'Esta operação conflita com uma alteração recente. Atualize e tente novamente.' });
    if (!error.status) console.error('Falha interna da API:', error.name);
    res.status(error.status || 500).json({ error: error.status ? error.message : 'Não foi possível concluir a operação.' });
  });
  let closed = false;
  return { app, db, close() {
    if (closed) return;
    closed = true;
    for (const stream of streams) {
      clearInterval(stream.heartbeat);
      stream.res.end();
    }
    streams.clear();
    db.close();
  } };
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const { app, close } = createApp({ demoMode: process.env.REA_DEMO_MODE === '1', allowedOrigins: (process.env.CORS_ALLOW_ORIGINS || '').split(',').filter(Boolean) });
  const host = process.env.HOST || '127.0.0.1';
  const port = Number(process.env.PORT || 3001);
  const server = app.listen(port, host, (error) => {
    if (error) {
      const reason = error.code === 'EADDRINUSE'
        ? 'endereço/porta já está em uso (EADDRINUSE)'
        : (error.code || error.message);
      console.error(`Não foi possível iniciar REA em ${host}:${port}: ${reason}.`);
      close();
      process.exitCode = 1;
      return;
    }
    console.log(`REA API em ${host}:${server.address().port}${process.env.REA_DEMO_MODE === '1' ? ' · demonstração local' : ''}`);
  });
  const stop = () => {
    server.close(() => process.exit(0));
    // SSE connections otherwise keep server.close waiting indefinitely.
    close();
    server.closeIdleConnections();
  };
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
}
