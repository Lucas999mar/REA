import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { hashPassword } from './auth.js';
import { defaultSettings, places } from './places.js';
export function openDatabase(path, demoMode = false) {
  if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
  const db = new DatabaseSync(path);
  db.exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE,
      password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('admin','rider','driver')),
      phone TEXT NOT NULL DEFAULT '', approved INTEGER NOT NULL DEFAULT 0, online INTEGER NOT NULL DEFAULT 0,
      vehicle_json TEXT, lat REAL, lng REAL, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), expires_at INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS session_expiry ON sessions(expires_at);
    CREATE TABLE IF NOT EXISTS settings (id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS app_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS rides (
      id TEXT PRIMARY KEY, rider_id TEXT NOT NULL REFERENCES users(id), driver_id TEXT REFERENCES users(id),
      origin_json TEXT NOT NULL, destination_json TEXT NOT NULL, category TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('requested','accepted','arrived','in_progress','completed','cancelled')),
      distance_km REAL NOT NULL, duration_minutes INTEGER NOT NULL, total_cents INTEGER NOT NULL,
      commission_cents INTEGER NOT NULL, payment_method TEXT NOT NULL DEFAULT 'cash',
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL, rating INTEGER CHECK(rating BETWEEN 1 AND 5)
    );
    CREATE UNIQUE INDEX IF NOT EXISTS one_active_rider ON rides(rider_id) WHERE status IN ('requested','accepted','arrived','in_progress');
    CREATE UNIQUE INDEX IF NOT EXISTS one_active_driver ON rides(driver_id) WHERE driver_id IS NOT NULL AND status IN ('accepted','arrived','in_progress');
  `);
  db.prepare('INSERT OR IGNORE INTO settings(id,value) VALUES (1,?)').run(JSON.stringify(defaultSettings));
  // Recognize databases from the first local demo as well as newly marked ones.
  if (db.prepare("SELECT id FROM users WHERE id='demo-admin' AND email='admin@rea.local'").get()) {
    db.prepare("INSERT OR IGNORE INTO app_meta(key,value) VALUES ('mode','demo')").run();
  }
  const databaseMode = db.prepare("SELECT value FROM app_meta WHERE key='mode'").get()?.value;
  const userCount = db.prepare('SELECT COUNT(*) AS count FROM users').get().count;
  if (!demoMode && databaseMode === 'demo') {
    db.close();
    throw new Error('Este banco contém contas demonstrativas. Use REA_DEMO_MODE=1 ou escolha um DATA_DIR diferente para o modo normal.');
  }
  if (demoMode && databaseMode !== 'demo' && userCount > 0) {
    db.close();
    throw new Error('Este banco possui contas reais. Escolha um DATA_DIR separado e vazio para a demonstração.');
  }
  if (demoMode && userCount === 0) {
    const now = new Date().toISOString();
    const passwordHash = hashPassword('ReaDemo!2026');
    const insert = db.prepare('INSERT INTO users(id,name,email,password_hash,role,phone,approved,online,vehicle_json,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)');
    db.exec('BEGIN IMMEDIATE');
    try {
      insert.run('demo-admin','Marina Costa','admin@rea.local',passwordHash,'admin','',1,0,null,now);
      insert.run('demo-rider','Ana Oliveira','passageiro@rea.local',passwordHash,'rider','',1,0,null,now);
      insert.run('demo-driver','Lucas Almeida','motorista@rea.local',passwordHash,'driver','',1,1,JSON.stringify({ model: 'Toyota Corolla', plate: 'REA1A23', color: 'Prata' }),now);
      const insertRide = db.prepare('INSERT INTO rides(id,rider_id,driver_id,origin_json,destination_json,category,status,distance_km,duration_minutes,total_cents,commission_cents,created_at,updated_at,rating) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
      for (let i = 0; i < 8; i++) {
        const when = new Date(Date.now() - (i + 1) * 3600_000 * 8).toISOString();
        const total = 1750 + i * 220;
        insertRide.run(`demo-ride-${i}`, 'demo-rider','demo-driver',JSON.stringify(places[i % places.length]),JSON.stringify(places[(i + 2) % places.length]), i % 3 === 0 ? 'comfort' : 'economy','completed',4.6 + i * .5,14 + i,total,Math.round(total * .15),when,when,5);
      }
      db.prepare("INSERT OR REPLACE INTO app_meta(key,value) VALUES ('mode','demo')").run();
      db.exec('COMMIT');
    } catch (error) { db.exec('ROLLBACK'); db.close(); throw error; }
  }
  return db;
}
