import { randomUUID } from 'node:crypto';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDatabase } from './database.js';
import { hashPassword } from './auth.js';
const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const password = process.env.ADMIN_PASSWORD || '';
if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 12 || password.length > 128) {
  console.error('Defina ADMIN_EMAIL e ADMIN_PASSWORD (12–128 caracteres) antes de executar. Nenhuma conta foi alterada.');
  process.exitCode = 1;
} else {
  const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
  const db = openDatabase(join(process.env.DATA_DIR || join(root, '.data'), 'rea.sqlite'));
  try {
    if (db.prepare('SELECT id FROM users WHERE email=?').get(email)) throw new Error('Já existe uma conta com esse e-mail; nenhuma alteração foi feita.');
    db.prepare('INSERT INTO users(id,name,email,password_hash,role,phone,approved,created_at) VALUES (?,?,?,?,?,?,?,?)').run(randomUUID(), process.env.ADMIN_NAME || 'Administrador', email, hashPassword(password), 'admin', '', 1, new Date().toISOString());
    console.log('Conta de administrador criada.');
  } catch (error) { console.error(error.message); process.exitCode = 1; }
  finally { db.close(); }
}
