import { randomBytes, scryptSync, timingSafeEqual, createHash } from 'node:crypto';
export function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  return `scrypt$${salt}$${scryptSync(password, salt, 64).toString('hex')}`;
}
export function verifyPassword(password, encoded) {
  const [, salt, key] = encoded.split('$');
  if (!salt || !key) return false;
  const stored = Buffer.from(key, 'hex');
  const attempt = scryptSync(password, salt, 64);
  return stored.length === attempt.length && timingSafeEqual(stored, attempt);
}
export const tokenHash = (token) => createHash('sha256').update(token).digest('hex');
export const newToken = () => randomBytes(32).toString('hex');
export function requestToken(req) {
  const authorization = req.get('authorization');
  if (authorization) return authorization.startsWith('Bearer ') ? authorization.slice(7) : null;
  const cookie = (req.get('cookie') || '').split(';').find((part) => part.trim().startsWith('rea_session='));
  return cookie ? cookie.trim().slice('rea_session='.length) : null;
}
