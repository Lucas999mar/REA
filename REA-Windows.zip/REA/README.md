# REA Mobilidade

Primeira versão de um sistema de corridas com aplicativos **Android/iOS de passageiro e motorista**, painel **superadmin web** e uma API compartilhada com SQLite.

O código da ferramenta de análise `morluto/rea` está instalado separadamente em `/workspace/rea-toolkit`. Este projeto de mobilidade está em `/workspace/REA`. As páginas públicas da Machine foram consultadas; a comparação está em [referência funcional](docs/REFERENCIA-MACHINE.md). Veja também [escopo e limites](docs/ESCOPO.md): a primeira versão não equivale à totalidade desse produto.

## Abrir no Windows

Extraia o pacote completo, instale Node.js 24.22.1 ou uma versão 24.x mais recente e execute `INICIAR-REA.cmd`. Veja [o guia para abrir e navegar](docs/ABRIR-DEMO.md).

Para ver os aplicativos no Android pelo Expo Go, use `INICIAR-REA-REDE.cmd` e os atalhos `ABRIR-PASSAGEIRO.cmd` / `ABRIR-MOTORISTA.cmd`. Veja [o passo a passo para Android](docs/ABRIR-APPS-ANDROID.md).

## Executar no ambiente preparado

Node **24.22.1** e npm **11.16.0** estão instalados em `/workspace/.rea-tools`. Em cada terminal:

```bash
source /workspace/.rea-tools/activate.sh
cd /workspace/REA
```

Para iniciar a API e servir o painel compilado com dados locais de demonstração:

```bash
npm run build
REA_DEMO_MODE=1 DATA_DIR=/workspace/REA/.data/demo npm start
```

O processo escuta `127.0.0.1`, porta **3001**. O modo demo é explícito; cria usuários e corridas fictícias persistentes. O banco demo não pode ser reaberto em modo normal. Não o utilize para operações reais.

| Perfil | E-mail local de demonstração |
| --- | --- |
| Superadmin | `admin@rea.local` |
| Passageiro | `passageiro@rea.local` |
| Motorista aprovado | `motorista@rea.local` |

A senha de todas as contas **de demonstração** é `ReaDemo!2026`. Esses dados não representam credenciais de nenhum serviço externo.

Para editar o painel com atualização automática, deixe a API rodando e execute `npm run dev` em outro terminal. O Vite usa a porta **5173** e encaminha `/api` para a API local. `npm run dev:server` reinicia o backend ao editar seus arquivos.

## Aplicativos Android/iOS

Os dois aplicativos compartilham componentes, mas possuem nomes, esquemas e identificadores próprios. As interfaces exibidas e o papel permitido são definidos no build por `APP_VARIANT`.

```bash
source /workspace/.rea-tools/activate.sh
cd /workspace/REA/apps/mobile
npm run start:rider -- --offline --port 8081
# Em outro terminal, para o app de motorista:
npm run start:driver -- --offline --port 8082
```

Configure `EXPO_PUBLIC_API_URL` para um endereço da API acessível ao dispositivo. O endereço loopback padrão serve apenas ao desenvolvimento na mesma máquina; em um celular físico, loopback aponta para o próprio celular. Para teste em uma rede local sob seu controle, a API pode ser iniciada com `HOST=0.0.0.0`, e o app deve usar o endereço da máquina nessa rede. Um ambiente de nuvem precisa de um endpoint HTTPS acessível ao dispositivo antes desse teste. Este onboarding não publica nem expõe portas automaticamente.

Veja [instruções dos aplicativos](apps/mobile/README.md) para Expo, variantes, exportação e localização. Exportar bundles não gera APK/AAB/IPA nem publica nas lojas.

## Banco sem dados de demonstração

Escolha outro `DATA_DIR` e mantenha `REA_DEMO_MODE=0`. Crie o primeiro superadmin pelo comando abaixo; a senha é lida de forma oculta no terminal, nunca deve ser gravada no repositório:

```bash
export DATA_DIR=/workspace/REA/.data/development
export ADMIN_EMAIL='admin@seu-dominio.example'
export ADMIN_NAME='Administrador'
read -rsp 'Senha do administrador (mínimo 12 caracteres): ' ADMIN_PASSWORD
export ADMIN_PASSWORD
npm run admin:create
unset ADMIN_PASSWORD
REA_DEMO_MODE=0 npm start
```

Depois, passageiro e motorista se cadastram nos apps. O superadmin aprova o motorista. O arquivo `.env.example` é uma referência: o servidor lê variáveis exportadas no processo e não carrega `.env` automaticamente.

## Fluxo compartilhado

- **Passageiro:** cadastro, seleção de origem/destino, estimativa, solicitação, acompanhamento, cancelamento antes do início, avaliação e histórico.
- **Motorista:** cadastro e veículo, aprovação, disponibilidade, aceite, chegada, início, conclusão, histórico e ganhos calculados. Localização opcional apenas em primeiro plano.
- **Superadmin:** indicadores da operação, corridas e detalhes, passageiros, aprovação de motoristas e tarifas/comissão. Atualizações por SSE com consulta periódica de recuperação.

A API determina preços e transições. Senhas usam scrypt. Sessões são persistidas por hash; o web usa cookie HttpOnly e os apps armazenam tokens no SecureStore. Passageiros só veem suas corridas e motoristas só veem as atribuídas ou disponíveis dentro de seu perfil.

Nesta versão, os locais são uma lista de pontos de São Paulo, as distâncias são estimadas e o pagamento é registrado em dinheiro. Não há cobrança online, repasses, geocodificação, trânsito, push ou rastreamento em segundo plano. Os códigos do app são uma base funcional para desenvolvimento, não uma operação comercial já homologada.

## Validação

```bash
cd /workspace/REA
npm test
npm run build
cd apps/mobile
npm run export:rider
npm run export:driver
```

Os testes da API verificam o ciclo completo, isolamento de permissões, disputa pelo aceite, transições, tarifas, persistência de sessões e eventos. Os resultados efetivamente executados e limitações estão em [VALIDACAO.md](docs/VALIDACAO.md).

## Ferramenta REA

```bash
source /workspace/.rea-tools/activate.sh
rea --version
rea --help
```

A CLI está disponível; isso não registra um servidor MCP nesta conversa. O build e a análise local foram exercitados sem Ghidra ou Hopper, que são opcionais para outros tipos de alvo. Consulte [instruções do ambiente](docs/AMBIENTE.md) para reproduzir a instalação, validar a análise de navegador e continuar a investigação da referência.
