@echo off
call "%~dp0scripts\start-mobile.cmd" rider
exit /b %errorlevel%
