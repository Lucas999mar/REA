@echo off
call "%~dp0scripts\start-demo.cmd" rede
exit /b %errorlevel%
